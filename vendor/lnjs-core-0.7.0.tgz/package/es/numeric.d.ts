import Ray from "./ray";
export declare function rayEpsilon(r: Ray): number;
export declare function after(t: number): number;
export declare function quadratic(a: number, b: number, c: number): number[];
