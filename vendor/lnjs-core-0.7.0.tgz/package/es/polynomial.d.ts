export type Polynomial = number[];
export declare const add: (a: Polynomial, b: Polynomial) => Polynomial;
export declare const scale: (a: Polynomial, k: number) => Polynomial;
export declare const sub: (a: Polynomial, b: Polynomial) => Polynomial;
export declare function mul(a: Polynomial, b: Polynomial): Polynomial;
export declare function evaluate(a: Polynomial, x: number): number;
export declare function unique(values: number[]): number[];
/** Isolate real roots between derivative roots (monotone cells), including tangencies. */
export declare function roots(coefficients: Polynomial, lo?: number, hi?: number): number[];
