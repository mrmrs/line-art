import Mesh from "./mesh";
/**
 * Parses Wavefront OBJ files
 * @param data raw .OBJ file data
 */
export declare function loadOBJ(data: string): Mesh;
