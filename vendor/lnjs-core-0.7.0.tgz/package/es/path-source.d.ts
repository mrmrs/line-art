import type { ShapeT } from "./shape";
import type { Matrix } from "./matrix";
import type Vector from "./vector";
/** Internal provenance survives Boolean trimming and instance transforms. */
export interface PathSource {
    shape: ShapeT;
    matrix: Matrix;
}
export declare const pathSources: WeakMap<Vector[], PathSource>;
