import { ShapeT } from "./shape";
export default class Hit {
    shape: null | ShapeT;
    t: number;
    constructor(shape: null | ShapeT, t: number);
    ok(): boolean;
    min(b: Hit): Hit;
    max(b: Hit): Hit;
}
export declare const NoHit: Hit;
