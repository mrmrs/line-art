import Vector from "./vector";
import { Box } from "./box";
import Triangle from "./triangle";
import Ray from "./ray";
import Hit from "./hit";
import { Paths } from "./paths";
export declare enum Direction {
    Above = 0,
    Below = 1
}
export type ShapeFn = (x: number, y: number) => number;
export declare class Function {
    private grid;
    private mesh;
    private fn;
    private box;
    direction: Direction;
    readonly divisions: number;
    constructor(fn: (x: number, y: number) => number, box: Box, direction: Direction, divisions?: number);
    compile(): void;
    boundingBox(): Box;
    contains(p: Vector): boolean;
    private build;
    occlusionTriangles(): Triangle[];
    paths(): Paths;
    intersect(ray: Ray, tMin?: number, tMax?: number): Hit;
    occluded(ray: Ray, tMin: number, tMax: number): boolean;
}
