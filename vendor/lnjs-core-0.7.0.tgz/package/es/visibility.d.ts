import { PathSource } from "./path-source";
import Vector from "./vector";
import { Matrix } from "./matrix";
import { ShapeT } from "./shape";
import Triangle from "./triangle";
import Cube from "./cube";
import Scene from "./scene";
export type Interval = [number, number];
export interface VisibilityOptions {
    /** Projected tessellation target in pixels. Not a bound for arbitrary custom surfaces. */
    curveTolerance?: number;
    /** Maximum projected spacing for custom-shape fallback queries. */
    fallbackSpacing?: number;
    maxTriangles?: number;
    maxTests?: number;
    orthographic?: boolean;
    /** Direction from surface toward camera (required for orthographic fallback). */
    direction?: Vector;
}
export declare function clipSegment(a: Vector, b: Vector, m: Matrix): [Vector, Vector] | null;
export declare function mergeIntervals(intervals: Interval[]): Interval[];
export declare function complementIntervals(hidden: Interval[]): Interval[];
/** Camera-specific acceleration for continuous hidden-line removal. */
export declare class Visibility {
    readonly scene: Scene;
    readonly matrix: Matrix;
    readonly eye: Vector;
    readonly width: number;
    readonly height: number;
    private root;
    private fallback;
    private booleans;
    private roundOwners;
    private spheres;
    readonly stats: {
        triangles: number;
        tests: number;
        segments: number;
        fallbackRays: number;
    };
    private options;
    constructor(scene: Scene, matrix: Matrix, eye: Vector, width: number, height: number, options?: VisibilityOptions);
    /** Endpoints are already clipped world points; returned parameters are in projected space. */
    hidden(a: Vector, b: Vector, owner?: ShapeT, source?: PathSource): Interval[];
    visible(a: Vector, b: Vector, owner?: ShapeT, source?: PathSource): Interval[];
    private roundSelfIntervals;
    private sphereIntervals;
    private fallbackIntervals;
}
export declare function boxTriangles(box: Cube): Triangle[];
/** Clip, hide, and project paths without reconnecting across invisible intervals. */
export declare function renderPaths(paths: Vector[][], matrix: Matrix, width: number, height: number, visibility?: Visibility, maxVertices?: number): Vector[][];
