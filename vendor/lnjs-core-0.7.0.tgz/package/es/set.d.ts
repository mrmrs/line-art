export interface Hashable {
    hashCode(): string;
}
export declare class HashSet<T extends Hashable> {
    _data: Array<T>;
    _hashes: {
        [key: string]: boolean;
    };
    constructor();
    add(item: T): void;
    has(item: T): boolean;
    forEach(callback: (v: T, i: number) => void): void;
}
