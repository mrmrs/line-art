import { Box } from "./box";
import Ray from "./ray";
import Hit from "./hit";
import { ShapeT } from "./shape";
export type ShapeFilter = (shape: ShapeT) => boolean;
export interface TraversalStats {
    nodes: number;
    primitives: number;
}
export declare class Tree {
    box: Box;
    root: Node;
    stats: TraversalStats;
    constructor(shapes: ShapeT[]);
    intersect(r: Ray, tMin?: number, tMax?: number): Hit;
    occluded(r: Ray, tMin?: number, tMax?: number, filter?: ShapeFilter): boolean;
    resetStats(): void;
}
export declare class Node {
    box: Box;
    shapes: ShapeT[];
    left: Node | null;
    right: Node | null;
    constructor(shapes: ShapeT[], depth?: number);
    private overlaps;
    intersect(r: Ray, tMin: number, tMax: number, stats?: TraversalStats): Hit;
    occluded(r: Ray, tMin: number, tMax: number, stats: TraversalStats, filter?: ShapeFilter, checked?: boolean): boolean;
}
