import { ShapeT } from "./shape";
import { Box } from "./box";
import Vector from "./vector";
import Ray from "./ray";
import Hit from "./hit";
import { Paths } from "./paths";
export declare class Cylinder implements ShapeT {
    radius: number;
    z0: number;
    z1: number;
    constructor(radius: number, z0: number, z1: number);
    compile(): void;
    boundingBox(): Box;
    contains(v: Vector, f: number): boolean;
    intersect(ray: Ray, tMin?: number, tMax?: number): Hit;
    paths(): Paths;
}
export declare class OutlineCylinder extends Cylinder {
    eye: Vector;
    up: Vector;
    constructor(eye: Vector, up: Vector, radius: number, z0: number, z1: number);
    paths(): Paths;
}
