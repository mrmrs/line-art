type float32arr = [number, number, number];
declare class STLTriangle {
    v1: float32arr;
    v2: float32arr;
    v3: float32arr;
    constructor(v1: float32arr, v2: float32arr, v3: float32arr);
}
