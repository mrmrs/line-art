import Vector from "./vector";
import Triangle from "./triangle";
import { Paths } from "./paths";
import Mesh from "./mesh";
export default class Plane {
    point: Vector;
    normal: Vector;
    constructor(point: Vector, normal: Vector);
    intersectSegment(v0: Vector, v1: Vector): [Vector, boolean];
    intersectTriangle(t: Triangle): [Vector, Vector, boolean];
    intersectMesh(m: Mesh): Paths;
}
