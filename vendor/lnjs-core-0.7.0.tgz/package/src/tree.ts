import { Box, boxForShapes } from "./box";
import Ray from "./ray";
import Hit, { NoHit } from "./hit";
import { ShapeT } from "./shape";
import { rayEpsilon } from "./numeric";

const scratch: [number, number] = [0, 0];

export type ShapeFilter = (shape: ShapeT) => boolean;
export interface TraversalStats {
  nodes: number;
  primitives: number;
}
const area = (b: Box) => {
  const s = b.size();
  return 2 * (s.x * s.y + s.y * s.z + s.z * s.x);
};
const axisValue = (b: Box, axis: number) =>
  axis === 0 ? b.center().x : axis === 1 ? b.center().y : b.center().z;

// Object BVH: no duplicated primitives or retained internal-node shape arrays.
export class Tree {
  box: Box;
  root: Node;
  stats: TraversalStats = { nodes: 0, primitives: 0 };
  constructor(shapes: ShapeT[]) {
    this.root = new Node(shapes);
    this.box = this.root.box;
  }
  intersect(r: Ray, tMin = rayEpsilon(r), tMax = Infinity): Hit {
    return this.root.intersect(r, tMin, tMax, this.stats);
  }
  occluded(
    r: Ray,
    tMin = rayEpsilon(r),
    tMax = Infinity,
    filter?: ShapeFilter,
  ): boolean {
    return this.root.occluded(r, tMin, tMax, this.stats, filter);
  }
  resetStats() {
    this.stats.nodes = 0;
    this.stats.primitives = 0;
  }
}

export class Node {
  box: Box;
  shapes: ShapeT[];
  left: Node | null = null;
  right: Node | null = null;
  constructor(shapes: ShapeT[], depth = 0) {
    this.box = boxForShapes(shapes);
    this.shapes = shapes.slice();
    if (shapes.length <= 4 || depth >= 48) return;
    const bounds = shapes.map((s) => s.boundingBox());
    const parentArea = area(this.box);
    if (!(parentArea > 0)) return;
    let best = shapes.length,
      bestAxis = -1,
      bestSplit = 0,
      bestLo = 0,
      bestExtent = 0;
    const buckets = 12;
    for (let axis = 0; axis < 3; axis++) {
      const centers = bounds.map((b) => axisValue(b, axis));
      let lo = Infinity,
        hi = -Infinity;
      for (const c of centers) {
        lo = Math.min(lo, c);
        hi = Math.max(hi, c);
      }
      const extent = hi - lo;
      if (!(extent > 0)) continue;
      const counts = new Array<number>(buckets).fill(0),
        boxes = new Array<Box | null>(buckets).fill(null);
      for (let i = 0; i < shapes.length; i++) {
        const k = Math.min(
          buckets - 1,
          Math.floor(((centers[i] - lo) / extent) * buckets),
        );
        counts[k]++;
        boxes[k] = boxes[k] ? boxes[k]!.extend(bounds[i]) : bounds[i];
      }
      for (let split = 0; split < buckets - 1; split++) {
        let nl = 0,
          nr = 0,
          bl: Box | null = null,
          br: Box | null = null;
        for (let k = 0; k < buckets; k++)
          if (boxes[k]) {
            if (k <= split) {
              nl += counts[k];
              bl = bl ? bl.extend(boxes[k]!) : boxes[k];
            } else {
              nr += counts[k];
              br = br ? br.extend(boxes[k]!) : boxes[k];
            }
          }
        if (!bl || !br) continue;
        const cost = 1 + (nl * area(bl) + nr * area(br)) / parentArea;
        if (cost < best) {
          best = cost;
          bestAxis = axis;
          bestSplit = split;
          bestLo = lo;
          bestExtent = extent;
        }
      }
    }
    if (bestAxis < 0) return;
    const left: ShapeT[] = [],
      right: ShapeT[] = [];
    shapes.forEach((s, i) => {
      const k = Math.min(
        buckets - 1,
        Math.floor(
          ((axisValue(bounds[i], bestAxis) - bestLo) / bestExtent) * buckets,
        ),
      );
      (k <= bestSplit ? left : right).push(s);
    });
    if (!left.length || !right.length) return;
    this.left = new Node(left, depth + 1);
    this.right = new Node(right, depth + 1);
    this.shapes = [];
  }
  private overlaps(r: Ray, tMin: number, tMax: number): boolean {
    const [a, b] = this.box.intersect(r, tMin, tMax, scratch);
    return a <= b && b > tMin && a < tMax;
  }
  intersect(
    r: Ray,
    tMin: number,
    tMax: number,
    stats: TraversalStats = { nodes: 0, primitives: 0 },
  ): Hit {
    stats.nodes++;
    if (!this.overlaps(r, tMin, tMax)) return NoHit;
    if (!this.left || !this.right) {
      let best = NoHit;
      for (const shape of this.shapes) {
        stats.primitives++;
        const h = shape.intersect(r, tMin, Math.min(tMax, best.t));
        if (h.ok() && h.t > tMin && h.t < tMax && h.t < best.t) best = h;
      }
      return best;
    }
    const l = this.left.box.intersect(r, tMin, tMax, scratch)[0],
      r0 = this.right.box.intersect(r, tMin, tMax, scratch)[0];
    const first = l <= r0 ? this.left : this.right,
      second = l <= r0 ? this.right : this.left;
    const h = first.intersect(r, tMin, tMax, stats);
    return h.min(second.intersect(r, tMin, Math.min(tMax, h.t), stats));
  }
  occluded(
    r: Ray,
    tMin: number,
    tMax: number,
    stats: TraversalStats,
    filter?: ShapeFilter,
    checked = false,
  ): boolean {
    stats.nodes++;
    if (!checked && !this.overlaps(r, tMin, tMax)) return false;
    if (!this.left || !this.right) {
      for (const shape of this.shapes) {
        if (filter && !filter(shape)) continue;
        stats.primitives++;
        if (shape.occluded) {
          if (shape.occluded(r, tMin, tMax)) return true;
        } else {
          const h = shape.intersect(r, tMin, tMax);
          if (h.ok() && h.t > tMin && h.t < tMax) return true;
        }
      }
      return false;
    }
    const [la, lb] = this.left.box.intersect(r, tMin, tMax, scratch),
      [ra, rb] = this.right.box.intersect(r, tMin, tMax, scratch);
    const l = la <= lb && lb > tMin && la < tMax,
      rr = ra <= rb && rb > tMin && ra < tMax;
    if (!l && !rr) return false;
    if (!l) return this.right.occluded(r, tMin, tMax, stats, filter, true);
    if (!rr) return this.left.occluded(r, tMin, tMax, stats, filter, true);
    const first = la <= ra ? this.left : this.right,
      second = la <= ra ? this.right : this.left;
    return (
      first.occluded(r, tMin, tMax, stats, filter, true) ||
      second.occluded(r, tMin, tMax, stats, filter, true)
    );
  }
}
