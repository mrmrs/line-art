import { rayEpsilon, quadratic } from "./numeric";
import { ShapeT } from "./shape";
import Vector from "./vector";
import { Box } from "./box";
import Hit, { NoHit } from "./hit";
import Ray from "./ray";
import { Paths } from "./paths";

const EPS = 1e-9;

export default class Triangle implements ShapeT {
  v1: Vector;
  v2: Vector;
  v3: Vector;
  box: Box;
  constructor(v1: Vector, v2: Vector, v3: Vector) {
    this.v1 = v1;
    this.v2 = v2;
    this.v3 = v3;
    this.box = this.calculateBoundingBox();
  }

  toString() {
    return `v1: ${this.v1} v2: ${this.v2} v3: ${this.v3}`;
  }

  calculateBoundingBox(): Box {
    let min = this.v1.min(this.v2).min(this.v3);
    let max = this.v1.max(this.v2).max(this.v3);
    return new Box(min, max);
  }

  updateBoundingBox(): void {
    const box = this.calculateBoundingBox();
    this.box = box;
  }

  compile() {
    // Noop
  }

  boundingBox(): Box {
    return this.box;
  }

  contains(v: Vector, f: number): boolean {
    return false;
  }

  intersect(r: Ray, tMin = rayEpsilon(r), tMax = Infinity): Hit {
    // Watertight shear-space edge functions: shared edges use identical operands.
    const d = [r.direction.x, r.direction.y, r.direction.z];
    let kz = 0;
    if (Math.abs(d[1]) > Math.abs(d[kz])) kz = 1;
    if (Math.abs(d[2]) > Math.abs(d[kz])) kz = 2;
    if (d[kz] === 0) return NoHit;
    let kx = (kz + 1) % 3,
      ky = (kx + 1) % 3;
    if (d[kz] < 0) [kx, ky] = [ky, kx];
    const sx = d[kx] / d[kz],
      sy = d[ky] / d[kz],
      sz = 1 / d[kz];
    const points = [this.v1, this.v2, this.v3].map((v) => {
      const p = [v.x - r.origin.x, v.y - r.origin.y, v.z - r.origin.z];
      return [p[kx] - sx * p[kz], p[ky] - sy * p[kz], p[kz] * sz];
    });
    const [a, b, c] = points;
    const u = c[0] * b[1] - c[1] * b[0],
      v = a[0] * c[1] - a[1] * c[0],
      w = b[0] * a[1] - b[1] * a[0];
    if ((u < 0 || v < 0 || w < 0) && (u > 0 || v > 0 || w > 0)) return NoHit;
    const det = u + v + w;
    if (det === 0) return NoHit;
    const t = (u * a[2] + v * b[2] + w * c[2]) / det;
    return t > tMin && t < tMax ? new Hit(this, t) : NoHit;
  }

  paths(): Paths {
    return [
      [this.v1, this.v2],
      [this.v2, this.v3],
      [this.v3, this.v1],
    ];
  }
}
