import { PathSource } from "./path-source";
import Vector from "./vector";
import { Matrix, identity } from "./matrix";
import { ShapeT, TransformedShape, EmptyShape } from "./shape";
import { BooleanShape, CSGOperation } from "./csg";
import Cube from "./cube";
import { Sphere } from "./sphere";
import { Cylinder } from "./cylinder";
import Cone from "./cone";
import Mesh from "./mesh";
import { quadratic } from "./numeric";
import {
  Polynomial as P,
  add,
  sub,
  mul,
  scale,
  evaluate,
  roots,
  unique,
} from "./polynomial";

type Point = P[];
type Equation = { a: P; b: P; c: P };
type Expression = (p: Vector, inclusive?: boolean) => boolean;
const zero = new Vector(0, 0, 0);
const point = (a: Vector, b = zero, w: P = [1]): Point => [
  [a.x, b.x],
  [a.y, b.y],
  [a.z, b.z],
  w,
];
const lerp = (a: Vector, b: Vector, t: number) =>
  a.add(b.sub(a).multiplyScalar(t));

/** A local diagonal quadric (planes included), evaluated without expanding translations. */
class Surface {
  constructor(
    readonly inverse: Matrix,
    readonly center: Vector,
    readonly q: number[],
    readonly l: number[],
    readonly k: number,
  ) {}
  local(p: Point): Point {
    const m = this.inverse,
      c = this.center;
    const row = (x: number, y: number, z: number, w: number): P => [
      x * (p[0][0] ?? 0) +
        y * (p[1][0] ?? 0) +
        z * (p[2][0] ?? 0) +
        w * (p[3][0] ?? 0),
      x * (p[0][1] ?? 0) +
        y * (p[1][1] ?? 0) +
        z * (p[2][1] ?? 0) +
        w * (p[3][1] ?? 0),
    ];
    return [
      row(m.x00, m.x01, m.x02, m.x03 - c.x),
      row(m.x10, m.x11, m.x12, m.x13 - c.y),
      row(m.x20, m.x21, m.x22, m.x23 - c.z),
      p[3],
    ];
  }
  form(p: Point, r = p): P {
    // Both inputs are affine in the stroke parameter. Accumulate their three
    // coefficients directly; generic polynomial products here dominated renders.
    const result = [0, 0, 0];
    const accumulate = (a: P, b: P, k: number) => {
      if (!k) return;
      result[0] += k * (a[0] ?? 0) * (b[0] ?? 0);
      result[1] += k * ((a[0] ?? 0) * (b[1] ?? 0) + (a[1] ?? 0) * (b[0] ?? 0));
      result[2] += k * (a[1] ?? 0) * (b[1] ?? 0);
    };
    accumulate(p[3], r[3], this.k);
    for (let i = 0; i < 3; i++) {
      accumulate(p[i], r[i], this.q[i]);
      accumulate(p[i], r[3], this.l[i] / 2);
      accumulate(r[i], p[3], this.l[i] / 2);
    }
    return result;
  }
  at(p: Point): P {
    return this.form(this.local(p));
  }
  normal(p: Vector): Vector | undefined {
    const local = this.local(point(p));
    const xyz = local.slice(0, 3).map((x) => evaluate(x, 0));
    const terms = xyz.map((x, i) => this.q[i] * x * x + this.l[i] * x);
    const value = terms.reduce((a, b) => a + b, this.k);
    const error =
      128 *
      Number.EPSILON *
      (Math.abs(this.k) +
        xyz.reduce(
          (sum, x, i) =>
            sum + Math.abs(this.q[i] * x * x) + Math.abs(this.l[i] * x),
          0,
        ));
    if (Math.abs(value) > error) return undefined;
    const g = xyz.map((x, i) => 2 * this.q[i] * x + this.l[i]),
      m = this.inverse;
    return new Vector(
      m.x00 * g[0] + m.x10 * g[1] + m.x20 * g[2],
      m.x01 * g[0] + m.x11 * g[1] + m.x21 * g[2],
      m.x02 * g[0] + m.x12 * g[1] + m.x22 * g[2],
    );
  }
  pencil(o: Point, d: Point): Equation {
    const p = this.local(o),
      r = this.local(d);
    return { a: this.form(r), b: scale(this.form(p, r), 2), c: this.form(p) };
  }
}
const isZero = (p: P) => p.every((x) => x === 0);
function resultant(p: Equation, q: Equation): P {
  if (isZero(p.a)) {
    if (isZero(q.a)) return sub(mul(p.b, q.c), mul(q.b, p.c));
    return add(
      sub(mul(q.a, mul(p.c, p.c)), mul(q.b, mul(p.b, p.c))),
      mul(q.c, mul(p.b, p.b)),
    );
  }
  if (isZero(q.a)) return resultant(q, p);
  const ac = sub(mul(p.a, q.c), mul(q.a, p.c));
  const ab = sub(mul(p.a, q.b), mul(q.a, p.b));
  const bc = sub(mul(p.b, q.c), mul(q.b, p.c));
  return sub(mul(ac, ac), mul(ab, bc));
}

/** Compiled regularized solid. Finite analytic arrangements; no world/pixel stepping. */
export class Solid {
  private surfaces: Surface[] = [];
  readonly contains: Expression;
  private classificationCost = 1;
  private sources = new WeakMap<PathSource, Solid>();
  private coincidences = new WeakMap<PathSource, boolean>();
  constructor(shape: ShapeT, transform = identity()) {
    this.contains = this.compile(shape, transform);
  }
  private compile(shape: ShapeT, m: Matrix): Expression {
    if (shape instanceof TransformedShape)
      return this.compile(shape.shape, m.mul(shape.matrix));
    if (shape.occlusionShape) return this.compile(shape.occlusionShape, m);
    if (shape instanceof EmptyShape) return () => false;
    if (shape instanceof BooleanShape) {
      const a = this.compile(shape.a, m),
        b = this.compile(shape.b, m);
      switch (shape.op) {
        case CSGOperation.Union:
          return (p, f) => a(p, f) || b(p, f);
        case CSGOperation.Intersection:
          return (p, f) => a(p, f) && b(p, f);
        case CSGOperation.Difference:
          return (p, f) => a(p, f) && !b(p, !f);
        default:
          throw new Error("Unknown Boolean operation");
      }
    }
    if (m.x30 !== 0 || m.x31 !== 0 || m.x32 !== 0 || m.x33 !== 1)
      throw new Error("Boolean operands require affine transforms");
    const im = m.inverse();
    const surface = (q: number[], l: number[], k: number, c = zero) =>
      this.surfaces.push(new Surface(im, c, q, l, k));
    const plane = (n: Vector, p: Vector) =>
      surface([0, 0, 0], [n.x, n.y, n.z], 0, p);
    const range = (x: number, lo: number, hi: number, inclusive?: boolean) =>
      inclusive ? x >= lo && x <= hi : x > lo && x < hi;
    if (shape instanceof Cube) {
      for (const p of [shape.min, shape.max]) {
        plane(new Vector(1, 0, 0), p);
        plane(new Vector(0, 1, 0), p);
        plane(new Vector(0, 0, 1), p);
      }
      return (p, f) => {
        const v = im.mulPosition(p);
        return (
          range(v.x, shape.min.x, shape.max.x, f) &&
          range(v.y, shape.min.y, shape.max.y, f) &&
          range(v.z, shape.min.z, shape.max.z, f)
        );
      };
    }
    if (shape instanceof Sphere) {
      surface([1, 1, 1], [0, 0, 0], -(shape.radius ** 2), shape.center);
      return (p, f) => {
        const d = im.mulPosition(p).sub(shape.center).lengthSquared();
        return f ? d <= shape.radius ** 2 : d < shape.radius ** 2;
      };
    }
    if (shape instanceof Cylinder || shape instanceof Cone) {
      const z0 = shape instanceof Cylinder ? shape.z0 : 0;
      const z1 = shape instanceof Cylinder ? shape.z1 : shape.height;
      const k = shape instanceof Cone ? (shape.radius / shape.height) ** 2 : 0;
      surface(
        [1, 1, -k],
        [0, 0, 0],
        shape instanceof Cone ? 0 : -(shape.radius ** 2),
        new Vector(0, 0, shape instanceof Cone ? shape.height : 0),
      );
      plane(new Vector(0, 0, 1), new Vector(0, 0, z0));
      plane(new Vector(0, 0, 1), new Vector(0, 0, z1));
      return (p, f) => {
        const v = im.mulPosition(p),
          radius =
            shape instanceof Cone
              ? shape.radius * (1 - v.z / shape.height)
              : shape.radius;
        const d = v.x * v.x + v.y * v.y;
        return (
          range(v.z, z0, z1, f) &&
          (f ? d <= radius * radius : d < radius * radius)
        );
      };
    }
    if (shape instanceof Mesh) {
      this.classificationCost += shape.triangles.length;
      const faces = shape.triangles.map((t) => ({
        t,
        n: t.v2.sub(t.v1).cross(t.v3.sub(t.v1)).normalize(),
      }));
      const onBoundary = (p: Vector) =>
        faces.some(({ t, n }) => {
          const v = [t.v1, t.v2, t.v3];
          const epsilon =
            64 *
            Number.EPSILON *
            Math.max(
              1e-100,
              ...[p, ...v].flatMap((v) => [
                Math.abs(v.x),
                Math.abs(v.y),
                Math.abs(v.z),
              ]),
            );
          if (Math.abs(p.sub(t.v1).dot(n)) > epsilon) return false;
          for (let i = 0; i < 3; i++) {
            const edge = v[(i + 1) % 3].sub(v[i]);
            if (edge.cross(p.sub(v[i])).dot(n) < -epsilon * edge.length())
              return false;
          }
          return true;
        });
      const edges = new Map<string, { count: number; winding: number }>();
      const key = (v: Vector) => `${v.x},${v.y},${v.z}`;
      for (const t of shape.triangles) {
        const v = [t.v1, t.v2, t.v3],
          normal = t.v2.sub(t.v1).cross(t.v3.sub(t.v1));
        if (!(normal.length() > 0))
          throw new Error("Boolean meshes cannot contain degenerate triangles");
        plane(normal.normalize(), t.v1);
        for (let i = 0; i < 3; i++) {
          const a = v[i],
            b = v[(i + 1) % 3],
            ka = key(a),
            kb = key(b),
            forward = ka < kb;
          const k = forward ? `${ka}|${kb}` : `${kb}|${ka}`;
          const e = edges.get(k) ?? { count: 0, winding: 0 };
          e.count++;
          e.winding += forward ? 1 : -1;
          edges.set(k, e);
          // Domain boundaries: a face-plane root crossing an edge changes membership.
          plane(b.sub(a).cross(normal).normalize(), a);
        }
      }
      if ([...edges.values()].some((e) => e.count !== 2 || e.winding !== 0))
        throw new Error(
          "Boolean meshes must be closed and consistently wound (two opposite faces per edge)",
        );
      return (p, inclusive) => {
        const local = im.mulPosition(p);
        return onBoundary(local) ? !!inclusive : shape.contains(local, 0);
      };
    }
    throw new Error(
      `Exact Boolean clipping does not support ${shape.constructor.name}; use closed cubes, spheres, cylinders, cones or meshes`,
    );
  }
  /** Boundary parameters on a world-space segment; used to trim operand strokes. */
  cuts(a: Vector, b: Vector): number[] {
    const p = point(a, b.sub(a));
    return unique([0, 1, ...this.surfaces.flatMap((s) => roots(s.at(p)))]);
  }
  /** Resolve shared curved surfaces before classifying their approximating chords. */
  coincidentSource(source: PathSource, p: Vector): Vector | undefined {
    const shape = source.shape;
    if (!(
      shape instanceof Sphere ||
      shape instanceof Cylinder ||
      shape instanceof Cone
    ))
      return;
    let solid = this.sources.get(source);
    if (!solid) {
      solid = new Solid(shape, source.matrix);
      this.sources.set(source, solid);
    }
    let coincident = this.coincidences.get(source);
    if (coincident === undefined) {
      const curved = solid.surfaces.find((s) => s.q.some((x) => x !== 0))!;
      const key = (s: Surface) =>
        JSON.stringify([s.inverse, s.center, s.q, s.l, s.k]);
      const target = key(curved);
      coincident = this.surfaces.some((s) => key(s) === target);
      this.coincidences.set(source, coincident);
    }
    if (!coincident) return;
    const local = source.matrix.inverse().mulPosition(p);
    let projected: Vector;
    if (shape instanceof Sphere)
      projected = local
        .sub(shape.center)
        .normalize()
        .multiplyScalar(shape.radius)
        .add(shape.center);
    else {
      const radius =
        shape instanceof Cone
          ? shape.radius * (1 - local.z / shape.height)
          : shape.radius;
      const radial = Math.hypot(local.x, local.y);
      if (radial === 0) return;
      projected = new Vector(
        (local.x * radius) / radial,
        (local.y * radius) / radial,
        local.z,
      );
    }
    return source.matrix.mulPosition(projected);
  }
  /** Classify neighboring cells perpendicular to a coincident operand stroke. */
  boundary(p: Vector, tangent: Vector): boolean {
    return this.neighborhood(p, tangent) === 0;
  }
  // -1 exterior, 0 boundary, 1 interior of the regularized Boolean result.
  private neighborhood(
    p: Vector,
    tangent: Vector,
    charge: (work: number) => void = () => {},
  ): number {
    const t = tangent.normalize();
    const u = t
      .cross(Math.abs(t.x) < 0.8 ? new Vector(1, 0, 0) : new Vector(0, 1, 0))
      .normalize();
    const v = t.cross(u),
      angles: number[] = [];
    for (const surface of this.surfaces) {
      const n = surface.normal(p);
      if (!n || n.length() === 0) continue;
      const x = n.dot(u),
        y = n.dot(v);
      if (x === 0 && y === 0) continue;
      const angle = (Math.atan2(-x, y) + 2 * Math.PI) % (2 * Math.PI);
      angles.push(angle, (angle + Math.PI) % (2 * Math.PI));
    }
    const stops = unique(angles);
    if (!stops.length) return this.contains(p) ? 1 : -1;
    charge(stops.length * (this.surfaces.length + this.classificationCost));
    let inside = false,
      outside = false;
    for (let i = 0; i < stops.length; i++) {
      const angle =
        (stops[i] +
          (i + 1 < stops.length ? stops[i + 1] : stops[0] + 2 * Math.PI)) /
        2;
      const d = u
        .multiplyScalar(Math.cos(angle))
        .add(v.multiplyScalar(Math.sin(angle)));
      let step = Infinity;
      const error =
        256 *
        Number.EPSILON *
        Math.max(Math.abs(p.x), Math.abs(p.y), Math.abs(p.z), 1e-100);
      for (const surface of this.surfaces) {
        const q = surface.pencil(point(p), point(d, zero, [0]));
        for (const root of quadratic(
          evaluate(q.a, 0),
          evaluate(q.b, 0),
          evaluate(q.c, 0),
        ))
          if (root > error) step = Math.min(step, root / 2);
      }
      if (!Number.isFinite(step)) step = Math.max(p.length(), 1) * 1e-4;
      if (this.contains(p.add(d.multiplyScalar(step)))) inside = true;
      else outside = true;
      if (inside && outside) return 0;
    }
    return inside ? 1 : -1;
  }
  /** Hidden intervals in world-segment parameter space, clipped at the camera near plane. */
  hidden(
    a: Vector,
    b: Vector,
    matrix: Matrix,
    eye: Vector,
    direction: Vector | undefined,
    charge: (work: number) => void,
    source?: PathSource,
  ): [number, number][] {
    const delta = b.sub(a),
      p = point(a, delta);
    const depthScale = direction
      ? Math.max(
          ...[a, b].flatMap((p) => [
            Math.abs(p.x),
            Math.abs(p.y),
            Math.abs(p.z),
          ]),
          1e-100,
        ) / direction.length()
      : 1;
    const depthError = 64 * Number.EPSILON * depthScale;
    const o = direction ? p : point(eye);
    const d = direction
      ? point(direction, zero, [0])
      : point(a.sub(eye), delta, [0]);
    const n = new Vector(
      matrix.x20 + matrix.x30,
      matrix.x21 + matrix.x31,
      matrix.x22 + matrix.x32,
    );
    const k = matrix.x23 + matrix.x33;
    const sourceNear: P = [n.dot(a) + k, n.dot(delta)];
    const nearNumerator: P = direction
      ? scale(sourceNear, -1)
      : [-n.dot(eye) - k];
    const nearDenominator: P = direction
      ? [n.dot(direction)]
      : [n.dot(a.sub(eye)), n.dot(delta)];
    // Homogeneous near point avoids rational polynomial expansion.
    const near: Point = o.map((x, i) =>
      add(mul(x, nearDenominator), mul(d[i], nearNumerator)),
    );
    charge((this.surfaces.length * (this.surfaces.length + 1)) / 2);
    const equations = this.surfaces.map((s) => s.pencil(o, d));
    let curved: Solid | undefined;
    if (
      source &&
      (source.shape instanceof Sphere ||
        source.shape instanceof Cylinder ||
        source.shape instanceof Cone)
    ) {
      curved = this.sources.get(source);
      if (!curved) {
        curved = new Solid(source.shape, source.matrix);
        this.sources.set(source, curved);
      }
    }
    const sourceEquations =
      curved?.surfaces
        .filter((s) => s.q.some((x) => x !== 0) || (s.normal(a) && s.normal(b)))
        .map((s) => s.pencil(o, d)) ?? [];
    const cuts = [0, 1];
    const addRoots = (q: P) => {
      cuts.push(...roots(q));
    };
    addRoots(nearDenominator);
    for (const q of sourceEquations)
      addRoots(add(q.b, scale(q.a, direction ? 0 : 2)));
    for (let i = 0; i < equations.length; i++) {
      const q = equations[i];
      addRoots(q.a);
      addRoots(q.b);
      addRoots(sub(mul(q.b, q.b), scale(mul(q.a, q.c), 4)));
      addRoots(this.surfaces[i].at(p));
      addRoots(this.surfaces[i].at(near));
      for (let j = 0; j < i; j++) {
        const other = equations[j];
        // A shared root for every ray (e.g. an eye at two cone apices) makes
        // the resultant identically zero. Its subresultants retain the other
        // boundary-order events in that degenerate pencil.
        const event = resultant(q, other);
        if (isZero(event) && !isZero(q.a) && !isZero(other.a)) {
          addRoots(sub(mul(q.a, other.b), mul(other.a, q.b)));
          addRoots(sub(mul(q.a, other.c), mul(other.a, q.c)));
          addRoots(sub(mul(q.b, other.c), mul(other.b, q.c)));
        } else addRoots(event);
      }
    }
    const stops = unique(cuts),
      out: [number, number][] = [];
    for (let i = 1; i < stops.length; i++) {
      const s = stops[i - 1] + (stops[i] - stops[i - 1]) / 2;
      const nearU = evaluate(nearNumerator, s) / evaluate(nearDenominator, s);
      let sourceU = direction ? 0 : 1;
      // Chords approximate a curved source surface. Move only their depth to the
      // nearest source boundary on this viewing ray; screen coordinates stay fixed.
      if (sourceEquations.length) {
        const nominal = sourceU;
        const candidates: number[] = [];
        for (const q of sourceEquations) {
          let best = Infinity,
            nearest: number | undefined;
          for (const u of quadratic(
            evaluate(q.a, s),
            evaluate(q.b, s),
            evaluate(q.c, s),
          )) {
            const distance = Math.abs(u - nominal);
            const tied = Math.abs(distance - best) <= depthError;
            if (
              nearest === undefined ||
              (!tied && distance < best) ||
              (tied && (direction ? u > nearest : u < nearest))
            ) {
              best = distance;
              nearest = u;
            }
          }
          if (nearest !== undefined) candidates.push(nearest);
        }
        // At a rim both cap and side are incident: either may face the camera.
        if (candidates.length)
          sourceU = direction
            ? Math.max(...candidates)
            : Math.min(...candidates);
      }
      if (
        !Number.isFinite(nearU) ||
        (direction ? sourceU >= nearU : sourceU <= nearU)
      )
        continue;
      const lo = Math.min(nearU, sourceU),
        hi = Math.max(nearU, sourceU);
      const us = [lo, hi];
      for (const q of equations)
        for (const u of quadratic(
          evaluate(q.a, s),
          evaluate(q.b, s),
          evaluate(q.c, s),
        ))
          if (
            u > lo &&
            u < hi &&
            Math.abs(u - sourceU) >
              64 * Number.EPSILON * Math.max(depthScale, Math.abs(sourceU))
          )
            us.push(u);
      const boundaries = unique(us),
        strokePoint = lerp(a, b, s);
      charge(boundaries.length * this.classificationCost);
      let hidden = false;
      for (let j = 1; j < boundaries.length; j++) {
        const u = boundaries[j - 1] + (boundaries[j] - boundaries[j - 1]) / 2;
        const world = direction
          ? strokePoint.add(direction.multiplyScalar(u))
          : eye.add(strokePoint.sub(eye).multiplyScalar(u));
        if (
          this.contains(world) ||
          (this.contains(world, true) &&
            this.neighborhood(
              world,
              direction ?? strokePoint.sub(eye),
              charge,
            ) === 1)
        ) {
          hidden = true;
          break;
        }
      }
      if (hidden) {
        const previous = out[out.length - 1];
        if (previous && previous[1] === stops[i - 1]) previous[1] = stops[i];
        else out.push([stops[i - 1], stops[i]]);
      }
    }
    return out;
  }
}
