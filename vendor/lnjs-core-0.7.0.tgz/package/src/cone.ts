import { rayEpsilon, quadratic } from "./numeric";
import { ShapeT } from "./shape";
import { Box } from "./box";
import Vector from "./vector";
import Ray from "./ray";
import Hit, { NoHit } from "./hit";
import { Paths } from "./paths";
import { Path } from "./path";
import { radians } from "./math";

export default class Cone implements ShapeT {
  radius: number;
  height: number;
  constructor(radius: number, height: number) {
    this.radius = radius;
    this.height = height;
  }

  compile() {
    // noop
  }

  boundingBox(): Box {
    let r = this.radius;
    return new Box(new Vector(-r, -r, 0), new Vector(r, r, this.height));
  }

  contains(v: Vector, f: number): boolean {
    if (v.z < -f || v.z > this.height + f) return false;
    return Math.hypot(v.x, v.y) <= this.radius * (1 - v.z / this.height) + f;
  }

  intersect(ray: Ray, tMin = rayEpsilon(ray), tMax = Infinity): Hit {
    const o = ray.origin,
      d = ray.direction,
      h = this.height,
      k = (this.radius / h) ** 2;
    let best = tMax;
    for (const t of quadratic(
      d.x * d.x + d.y * d.y - k * d.z * d.z,
      2 * (d.x * o.x + d.y * o.y - k * d.z * (o.z - h)),
      o.x * o.x + o.y * o.y - k * (o.z - h) ** 2,
    )) {
      const z = o.z + t * d.z;
      if (t > tMin && t < best && z >= 0 && z <= h) best = t;
    }
    if (d.z !== 0) {
      const t = -o.z / d.z,
        x = o.x + t * d.x,
        y = o.y + t * d.y;
      if (t > tMin && t < best && x * x + y * y <= this.radius * this.radius)
        best = t;
    }
    return best < tMax ? new Hit(this, best) : NoHit;
  }

  paths(): Paths {
    let result: Paths = [];
    for (let a = 0; a < 360; a += 30) {
      let x = this.radius * Math.cos(radians(a));
      let y = this.radius * Math.sin(radians(a));
      let p: Path = [new Vector(x, y, 0), new Vector(0, 0, this.height)];
      result.push(p);
    }
    const ring: Path = [];
    for (let i = 0; i <= 360; i++) {
      const angle = radians(i % 360);
      ring.push(
        new Vector(
          this.radius * Math.cos(angle),
          this.radius * Math.sin(angle),
          0,
        ),
      );
    }
    result.push(ring);
    return result;
  }
}
