import Vector from "./vector";
import { Box } from "./box";
import Mesh from "./mesh";
import Triangle from "./triangle";
import Ray from "./ray";
import Hit from "./hit";
import { Paths } from "./paths";
export enum Direction {
  Above,
  Below,
}
export type ShapeFn = (x: number, y: number) => number;

// Paths and visibility share the same piecewise-planar surface. This avoids
// unrelated ray-march and line-grid approximations disagreeing at boundaries.
export class Function {
  private grid: Vector[][] | null = null;
  private mesh: Mesh | null = null;
  private fn: (x: number, y: number) => number;
  private box: Box;
  direction: Direction;
  readonly divisions: number;
  constructor(
    fn: (x: number, y: number) => number,
    box: Box,
    direction: Direction,
    divisions = 64,
  ) {
    this.fn = fn;
    this.box = box;
    this.direction = direction;
    if (!Number.isInteger(divisions) || divisions < 4 || divisions > 512)
      throw new Error("Height field divisions must be between 4 and 512");
    this.divisions = divisions;
  }
  compile() {
    this.build();
  }
  boundingBox() {
    return this.box;
  }
  contains(p: Vector) {
    return (
      this.box.contains(p) &&
      (this.direction === Direction.Above
        ? p.z > this.fn(p.x, p.y)
        : p.z < this.fn(p.x, p.y))
    );
  }
  private build() {
    if (this.mesh) return;
    const n = this.divisions,
      { min, max } = this.box;
    this.grid = Array.from({ length: n + 1 }, (_, y) =>
      Array.from({ length: n + 1 }, (_, x) => {
        const px = min.x + ((max.x - min.x) * x) / n,
          py = min.y + ((max.y - min.y) * y) / n;
        const z = this.fn(px, py);
        if (!Number.isFinite(z))
          throw new Error("Height field returned a non-finite value");
        return new Vector(px, py, z);
      }),
    );
    const triangles: Triangle[] = [];
    const add = (a: Vector, b: Vector, c: Vector) => {
      let polygon = [a, b, c];
      for (const [bound, sign] of [
        [min.z, 1],
        [max.z, -1],
      ]) {
        const out: Vector[] = [];
        for (let i = 0; i < polygon.length; i++) {
          const p = polygon[i],
            q = polygon[(i + 1) % polygon.length];
          const fa = (p.z - bound) * sign,
            fb = (q.z - bound) * sign;
          if (fa >= 0) out.push(p);
          if (fa < 0 !== fb < 0)
            out.push(p.add(q.sub(p).multiplyScalar(fa / (fa - fb))));
        }
        polygon = out;
      }
      for (let i = 1; i + 1 < polygon.length; i++)
        triangles.push(new Triangle(polygon[0], polygon[i], polygon[i + 1]));
    };
    for (let y = 0; y < n; y++)
      for (let x = 0; x < n; x++) {
        const a = this.grid[y][x],
          b = this.grid[y][x + 1],
          c = this.grid[y + 1][x + 1],
          d = this.grid[y + 1][x];
        add(a, b, c);
        add(a, c, d);
      }
    this.mesh = new Mesh(triangles);
  }
  occlusionTriangles() {
    this.build();
    return this.mesh!.triangles;
  }
  paths(): Paths {
    this.build();
    const paths: Paths = [],
      grid = this.grid!,
      n = grid.length;
    for (const swap of [false, true])
      for (let row = 0; row < n; row++) {
        let path: Vector[] = [];
        const flush = () => {
          if (path.length > 1) paths.push(path);
          path = [];
        };
        for (let column = 1; column < n; column++) {
          const a = swap ? grid[column - 1][row] : grid[row][column - 1];
          const b = swap ? grid[column][row] : grid[row][column];
          let lo = 0,
            hi = 1;
          for (const [bound, sign] of [
            [this.box.min.z, 1],
            [this.box.max.z, -1],
          ]) {
            const fa = (a.z - bound) * sign,
              fb = (b.z - bound) * sign;
            if (fa < 0 && fb < 0) {
              hi = -1;
              break;
            }
            if (fa < 0) lo = Math.max(lo, fa / (fa - fb));
            if (fb < 0) hi = Math.min(hi, fa / (fa - fb));
          }
          if (lo > hi) {
            flush();
            continue;
          }
          const p = a.add(b.sub(a).multiplyScalar(lo)),
            q = a.add(b.sub(a).multiplyScalar(hi));
          if (lo > 0) flush();
          if (!path.length) path.push(p);
          path.push(q);
          if (hi < 1) flush();
        }
        flush();
      }
    return paths;
  }
  intersect(ray: Ray, tMin?: number, tMax?: number): Hit {
    this.build();
    return this.mesh!.intersect(ray, tMin, tMax);
  }
  occluded(ray: Ray, tMin: number, tMax: number) {
    this.build();
    return this.mesh!.occluded(ray, tMin, tMax);
  }
}
