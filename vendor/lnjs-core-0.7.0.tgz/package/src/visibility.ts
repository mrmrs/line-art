import { pathSources, PathSource } from "./path-source";
import Vector from "./vector";
import { Matrix, identity } from "./matrix";
import { ShapeT, TransformedShape } from "./shape";
import Triangle from "./triangle";
import Mesh from "./mesh";
import Cube from "./cube";
import { Sphere } from "./sphere";
import { Cylinder } from "./cylinder";
import Cone from "./cone";
import { BooleanShape } from "./csg";
import Scene from "./scene";
import { Solid } from "./solid";
import Ray from "./ray";
import { rayEpsilon, quadratic } from "./numeric";

export type Interval = [number, number];
type ClipPoint = [number, number, number, number];
export interface VisibilityOptions {
  /** Projected tessellation target in pixels. Not a bound for arbitrary custom surfaces. */
  curveTolerance?: number;
  /** Maximum projected spacing for custom-shape fallback queries. */
  fallbackSpacing?: number;
  maxTriangles?: number;
  maxTests?: number;
  orthographic?: boolean;
  /** Direction from surface toward camera (required for orthographic fallback). */
  direction?: Vector;
}
interface Face {
  owner?: ShapeT;
  a: Vector;
  b: Vector;
  c: Vector;
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
}
interface IndexNode {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
  left?: IndexNode;
  right?: IndexNode;
  faces?: Face[];
}
function index(faces: Face[]): IndexNode {
  const n: IndexNode = {
    minX: Infinity,
    minY: Infinity,
    maxX: -Infinity,
    maxY: -Infinity,
  };
  for (const f of faces) {
    n.minX = Math.min(n.minX, f.minX);
    n.minY = Math.min(n.minY, f.minY);
    n.maxX = Math.max(n.maxX, f.maxX);
    n.maxY = Math.max(n.maxY, f.maxY);
  }
  if (faces.length <= 8) {
    n.faces = faces;
    return n;
  }
  const x = n.maxX - n.minX >= n.maxY - n.minY;
  faces.sort((a, b) =>
    x
      ? a.minX + a.maxX - (b.minX + b.maxX)
      : a.minY + a.maxY - (b.minY + b.maxY),
  );
  const mid = faces.length >> 1;
  n.left = index(faces.slice(0, mid));
  n.right = index(faces.slice(mid));
  return n;
}
const cross = (ax: number, ay: number, bx: number, by: number) =>
  ax * by - ay * bx;
function clipPositive(range: Interval, f0: number, f1: number): boolean {
  if (f0 < 0 && f1 < 0) return false;
  if (f0 < 0) range[0] = Math.max(range[0], f0 / (f0 - f1));
  if (f1 < 0) range[1] = Math.min(range[1], f0 / (f0 - f1));
  return range[0] < range[1];
}
function clip4(p: Vector, m: Matrix): ClipPoint {
  return [
    m.x00 * p.x + m.x01 * p.y + m.x02 * p.z + m.x03,
    m.x10 * p.x + m.x11 * p.y + m.x12 * p.z + m.x13,
    m.x20 * p.x + m.x21 * p.y + m.x22 * p.z + m.x23,
    m.x30 * p.x + m.x31 * p.y + m.x32 * p.z + m.x33,
  ];
}
export function clipSegment(
  a: Vector,
  b: Vector,
  m: Matrix,
): [Vector, Vector] | null {
  const ca = clip4(a, m),
    cb = clip4(b, m),
    r: Interval = [0, 1];
  for (let axis = 0; axis < 3; axis++)
    for (const sign of [-1, 1])
      if (!clipPositive(r, ca[3] + sign * ca[axis], cb[3] + sign * cb[axis]))
        return null;
  return [
    a.add(b.sub(a).multiplyScalar(r[0])),
    a.add(b.sub(a).multiplyScalar(r[1])),
  ];
}
function projectedFaces(tri: Triangle, m: Matrix): Face[] {
  let polygon = [clip4(tri.v1, m), clip4(tri.v2, m), clip4(tri.v3, m)];
  for (let axis = 0; axis < 3; axis++)
    for (const sign of [-1, 1]) {
      const out: ClipPoint[] = [];
      for (let i = 0; i < polygon.length; i++) {
        const a = polygon[i],
          b = polygon[(i + 1) % polygon.length],
          fa = a[3] + sign * a[axis],
          fb = b[3] + sign * b[axis];
        if (fa >= 0) out.push(a);
        if (fa < 0 !== fb < 0) {
          const t = fa / (fa - fb);
          out.push(a.map((v, j) => v + (b[j] - v) * t) as ClipPoint);
        }
      }
      polygon = out;
      if (polygon.length < 3) return [];
    }
  const p = polygon
    .filter((p) => p[3] > 0)
    .map((p) => new Vector(p[0] / p[3], p[1] / p[3], p[2] / p[3]));
  const faces: Face[] = [];
  for (let i = 1; i + 1 < p.length; i++) {
    const a = p[0],
      b = p[i],
      c = p[i + 1];
    if (cross(b.x - a.x, b.y - a.y, c.x - a.x, c.y - a.y) === 0) continue;
    faces.push({
      a,
      b,
      c,
      minX: Math.min(a.x, b.x, c.x),
      minY: Math.min(a.y, b.y, c.y),
      maxX: Math.max(a.x, b.x, c.x),
      maxY: Math.max(a.y, b.y, c.y),
    });
  }
  return faces;
}
// Exact for a projected triangle and segment, up to floating-point predicates.
// NDC depth is affine over projected planar geometry, including perspective.
function hiddenByFace(a: Vector, b: Vector, f: Face): Interval | null {
  const r: Interval = [0, 1],
    vertices = [f.a, f.b, f.c];
  const area = cross(
      f.b.x - f.a.x,
      f.b.y - f.a.y,
      f.c.x - f.a.x,
      f.c.y - f.a.y,
    ),
    sign = Math.sign(area);
  for (let i = 0; i < 3; i++) {
    const p = vertices[i],
      q = vertices[(i + 1) % 3],
      dx = q.x - p.x,
      dy = q.y - p.y;
    if (
      !clipPositive(
        r,
        sign * cross(dx, dy, a.x - p.x, a.y - p.y),
        sign * cross(dx, dy, b.x - p.x, b.y - p.y),
      )
    )
      return null;
  }
  const depth = (p: Vector) => {
    const u =
      cross(p.x - f.a.x, p.y - f.a.y, f.c.x - f.a.x, f.c.y - f.a.y) / area;
    const v =
      cross(f.b.x - f.a.x, f.b.y - f.a.y, p.x - f.a.x, p.y - f.a.y) / area;
    const z = f.a.z + u * (f.b.z - f.a.z) + v * (f.c.z - f.a.z);
    const error =
      128 *
      Number.EPSILON *
      (1 +
        Math.abs(p.z) +
        Math.abs(f.a.z) +
        Math.abs(u * (f.b.z - f.a.z)) +
        Math.abs(v * (f.c.z - f.a.z)));
    return p.z - z - error;
  };
  return clipPositive(r, depth(a), depth(b)) ? r : null;
}
export function mergeIntervals(intervals: Interval[]): Interval[] {
  intervals.sort((a, b) => a[0] - b[0]);
  const result: Interval[] = [];
  for (const interval of intervals) {
    if (!(interval[0] < interval[1])) continue;
    const last = result[result.length - 1];
    if (last && interval[0] <= last[1])
      last[1] = Math.max(last[1], interval[1]);
    else result.push([...interval]);
  }
  return result;
}
export function complementIntervals(hidden: Interval[]): Interval[] {
  const out: Interval[] = [];
  let t = 0;
  for (const [a, b] of mergeIntervals(hidden)) {
    if (a > t) out.push([t, a]);
    t = Math.max(t, b);
  }
  if (t < 1) out.push([t, 1]);
  return out;
}

/** Camera-specific acceleration for continuous hidden-line removal. */
export class Visibility {
  private root: IndexNode;
  private fallback: ShapeT[] = [];
  private booleans: { solid: Solid; owner: ShapeT }[] = [];
  private roundOwners = new Map<
    ShapeT,
    { shape: Cylinder | Cone; inverse: Matrix }
  >();
  private spheres: {
    sphere: Sphere;
    world: ShapeT;
    inverse: Matrix;
    owner: ShapeT;
  }[] = [];
  readonly stats = { triangles: 0, tests: 0, segments: 0, fallbackRays: 0 };
  private options: VisibilityOptions;
  constructor(
    readonly scene: Scene,
    readonly matrix: Matrix,
    readonly eye: Vector,
    readonly width: number,
    readonly height: number,
    options: VisibilityOptions = {},
  ) {
    if (!(width > 0 && height > 0 && Number.isFinite(width + height)))
      throw new Error("Viewport dimensions must be positive and finite");
    for (const value of [
      options.curveTolerance ?? 0.25,
      options.fallbackSpacing ?? 0.5,
      options.maxTriangles ?? 1000000,
      options.maxTests ?? 20000000,
    ])
      if (!(value > 0 && Number.isFinite(value)))
        throw new Error(
          "Visibility tolerances and budgets must be positive and finite",
        );
    const im = matrix.inverse();
    options = {
      ...options,
      orthographic:
        options.orthographic ??
        (matrix.x30 === 0 && matrix.x31 === 0 && matrix.x32 === 0),
      direction:
        options.direction ??
        im
          .mulPositionW(new Vector(0, 0, -1))
          .sub(im.mulPositionW(new Vector(0, 0, 1)))
          .normalize(),
    };
    this.options = options;
    const faces: Face[] = [];
    const add = (shape: ShapeT, m: Matrix, owner: ShapeT = shape) => {
      if (shape instanceof TransformedShape) {
        add(shape.shape, m.mul(shape.matrix), owner);
        return;
      }
      const custom = shape as ShapeT & {
        occlusionShape?: ShapeT;
        occlusionTriangles?: () => Triangle[];
      };
      if (custom.occlusionShape) {
        add(custom.occlusionShape, m, owner);
        return;
      }
      if (shape instanceof BooleanShape) {
        this.booleans.push({ solid: new Solid(shape, m), owner });
        return;
      }
      if (shape instanceof Sphere) {
        this.spheres.push({
          sphere: shape,
          world: m === base ? shape : new TransformedShape(shape, m),
          inverse: m.inverse(),
          owner,
        });
        return;
      }
      if (shape instanceof Cylinder || shape instanceof Cone)
        this.roundOwners.set(owner, { shape, inverse: m.inverse() });
      let triangles: Triangle[];
      if (custom.occlusionTriangles) triangles = custom.occlusionTriangles();
      else if (shape instanceof Mesh) triangles = shape.triangles;
      else if (shape instanceof Triangle) triangles = [shape];
      else if (shape instanceof Cube) triangles = boxTriangles(shape);
      else if (
        shape instanceof Sphere ||
        shape instanceof Cylinder ||
        shape instanceof Cone
      ) {
        const box = m.mulBox(shape.boundingBox()),
          p = [];
        let near = false;
        for (const x of [box.min.x, box.max.x])
          for (const y of [box.min.y, box.max.y])
            for (const z of [box.min.z, box.max.z]) {
              const c = clip4(new Vector(x, y, z), matrix);
              if (c[3] <= 0 || c[2] < -c[3]) near = true;
              else p.push(new Vector(c[0] / c[3], c[1] / c[3], 0));
            }
        let diameter = 2 * Math.max(width, height);
        if (!near && p.length)
          diameter = Math.max(
            ((Math.max(...p.map((p) => p.x)) - Math.min(...p.map((p) => p.x))) *
              width) /
              2,
            ((Math.max(...p.map((p) => p.y)) - Math.min(...p.map((p) => p.y))) *
              height) /
              2,
          );
        const tol = options.curveTolerance ?? 0.25;
        // Sagitta-based resolution target, with explicit work limits below.
        const segments = Math.max(
          12,
          Math.ceil(
            Math.PI /
              Math.acos(Math.max(-1, 1 - (2 * tol) / Math.max(diameter, tol))),
          ),
        );
        if (segments > 2048)
          throw new Error("Curve tolerance exceeds tessellation budget");
        triangles = roundTriangles(shape, segments);
      } else {
        this.fallback.push(m === base ? shape : new TransformedShape(shape, m));
        return;
      }
      this.stats.triangles += triangles.length;
      if (this.stats.triangles > (options.maxTriangles ?? 1000000))
        throw new Error("Occlusion triangle budget exceeded");
      for (const tri of triangles) {
        const t =
          m === base
            ? tri
            : new Triangle(
                m.mulPosition(tri.v1),
                m.mulPosition(tri.v2),
                m.mulPosition(tri.v3),
              );
        for (const face of projectedFaces(t, matrix)) {
          face.owner = owner;
          faces.push(face);
        }
      }
    };
    const base = identity();
    for (const shape of scene.shapes) add(shape, base);
    this.root = index(faces);
  }
  /** Endpoints are already clipped world points; returned parameters are in projected space. */
  hidden(
    a: Vector,
    b: Vector,
    owner?: ShapeT,
    source?: PathSource,
  ): Interval[] {
    this.stats.segments++;
    const pa = this.matrix.mulPositionW(a),
      pb = this.matrix.mulPositionW(b),
      out: Interval[] = [];
    const minX = Math.min(pa.x, pb.x),
      maxX = Math.max(pa.x, pb.x),
      minY = Math.min(pa.y, pb.y),
      maxY = Math.max(pa.y, pb.y);
    const visit = (n: IndexNode) => {
      if (n.maxX < minX || n.minX > maxX || n.maxY < minY || n.minY > maxY)
        return;
      if (n.faces)
        for (const face of n.faces) {
          if (owner && this.roundOwners.has(owner) && face.owner === owner)
            continue;
          if (++this.stats.tests > (this.options.maxTests ?? 20000000))
            throw new Error("Occlusion candidate budget exceeded");
          const interval = hiddenByFace(pa, pb, face);
          if (interval) out.push(interval);
        }
      else {
        if (n.left) visit(n.left);
        if (n.right) visit(n.right);
      }
    };
    visit(this.root);
    if (owner && this.roundOwners.has(owner))
      this.roundSelfIntervals(a, b, this.roundOwners.get(owner)!, out);
    for (const sphere of this.spheres)
      this.sphereIntervals(a, b, pa, pb, sphere, owner, out);
    for (const record of this.booleans) {
      const wa = clip4(a, this.matrix)[3],
        wb = clip4(b, this.matrix)[3];
      const projected = (s: number) => (s * wb) / ((1 - s) * wa + s * wb);
      const intervals = record.solid.hidden(
        a,
        b,
        this.matrix,
        this.eye,
        this.options.orthographic ? this.options.direction : undefined,
        (work) => {
          this.stats.tests += work;
          if (this.stats.tests > (this.options.maxTests ?? 20000000))
            throw new Error(
              "Boolean event budget exceeded; reduce operand complexity or increase maxTests",
            );
        },
        record.owner === owner ? source : undefined,
      );
      for (const [lo, hi] of intervals)
        out.push([projected(lo), projected(hi)]);
    }
    if (this.fallback.length) this.fallbackIntervals(a, b, pa, pb, out);
    return mergeIntervals(out);
  }
  visible(
    a: Vector,
    b: Vector,
    owner?: ShapeT,
    source?: PathSource,
  ): Interval[] {
    return complementIntervals(this.hidden(a, b, owner, source));
  }
  private roundSelfIntervals(
    a: Vector,
    b: Vector,
    record: { shape: Cylinder | Cone; inverse: Matrix },
    out: Interval[],
  ) {
    // Convex surface-owned strokes use analytic face orientation. This prevents
    // a smooth rim/chord from cutting through its coarser occluder tessellation.
    const { shape, inverse } = record,
      pa = inverse.mulPosition(a),
      pb = inverse.mulPosition(b),
      delta = pb.sub(pa),
      eye = inverse.mulPosition(this.eye);
    const d = this.options.direction!,
      m = inverse;
    const parallel = new Vector(
      m.x00 * d.x + m.x01 * d.y + m.x02 * d.z,
      m.x10 * d.x + m.x11 * d.y + m.x12 * d.z,
      m.x20 * d.x + m.x21 * d.y + m.x22 * d.z,
    );
    const lower = shape instanceof Cylinder ? shape.z0 : 0,
      upper = shape instanceof Cylinder ? shape.z1 : shape.height;
    const eps =
      64 * Number.EPSILON * Math.max(Math.abs(lower), Math.abs(upper), 1e-100);
    const onLower =
      Math.abs(pa.z - lower) <= eps && Math.abs(pb.z - lower) <= eps;
    const onUpper =
      shape instanceof Cylinder &&
      Math.abs(pa.z - upper) <= eps &&
      Math.abs(pb.z - upper) <= eps;
    const score = (u: number) => {
      const p = pa.add(delta.multiplyScalar(u)),
        view = this.options.orthographic ? parallel : eye.sub(p);
      const normal = new Vector(
        p.x,
        p.y,
        shape instanceof Cone
          ? (shape.radius / shape.height) ** 2 * (shape.height - p.z)
          : 0,
      );
      return [
        normal.dot(view),
        onLower ? -view.z : onUpper ? view.z : -Infinity,
      ];
    };
    const cuts = [0, 1],
      s0 = score(0),
      sm = score(0.5),
      s1 = score(1);
    for (let axis = 0; axis < 2; axis++)
      if (Number.isFinite(s0[axis])) {
        const c = s0[axis],
          aa = 2 * (s1[axis] + c - 2 * sm[axis]),
          bb = s1[axis] - c - aa;
        for (const u of quadratic(aa, bb, c)) if (u > 0 && u < 1) cuts.push(u);
      }
    cuts.sort((a, b) => a - b);
    const wa = clip4(a, this.matrix)[3],
      wb = clip4(b, this.matrix)[3],
      screen = (u: number) => (u * wb) / ((1 - u) * wa + u * wb);
    for (let i = 1; i < cuts.length; i++) {
      const lo = cuts[i - 1],
        hi = cuts[i],
        scores = score((lo + hi) / 2);
      if (hi > lo && scores[0] <= 0 && scores[1] <= 0)
        out.push([screen(lo), screen(hi)]);
    }
  }

  private sphereIntervals(
    a: Vector,
    b: Vector,
    pa: Vector,
    pb: Vector,
    record: (typeof this.spheres)[number],
    owner: ShapeT | undefined,
    out: Interval[],
  ) {
    if (++this.stats.tests > (this.options.maxTests ?? 20000000))
      throw new Error("Occlusion candidate budget exceeded");
    const { sphere, inverse, world } = record,
      r2 = sphere.radius * sphere.radius;
    const wa = clip4(a, this.matrix)[3],
      wb = clip4(b, this.matrix)[3],
      h0 = 1 / wa,
      h1 = 1 / wb;
    const la = inverse.mulPosition(a).sub(sphere.center),
      lb = inverse.mulPosition(b).sub(sphere.center);
    const u0 = la.multiplyScalar(h0),
      u1 = lb.multiplyScalar(h1);
    const roots: number[] = [0, 1];
    const addRoots = (aa: number, bb: number, cc: number) => {
      for (const t of quadratic(aa, bb, cc))
        if (t > 0 && t < 1 && Number.isFinite(t)) roots.push(t);
    };
    const sphereRoots = (u: Vector, v: Vector, h: number, k: number) => {
      const d = v.sub(u),
        dh = k - h;
      addRoots(
        d.dot(d) - r2 * dh * dh,
        2 * (u.dot(d) - r2 * h * dh),
        u.dot(u) - r2 * h * h,
      );
    };
    sphereRoots(u0, u1, h0, h1);
    if (this.options.orthographic) {
      const m = inverse,
        d = this.options.direction!;
      const dir = new Vector(
        m.x00 * d.x + m.x01 * d.y + m.x02 * d.z,
        m.x10 * d.x + m.x11 * d.y + m.x12 * d.z,
        m.x20 * d.x + m.x21 * d.y + m.x22 * d.z,
      );
      const c0 = u0.cross(dir),
        dc = u1.cross(dir).sub(c0),
        dh = h1 - h0,
        rr = r2 * dir.dot(dir);
      addRoots(
        rr * dh * dh - dc.dot(dc),
        2 * (rr * h0 * dh - c0.dot(dc)),
        rr * h0 * h0 - c0.dot(c0),
      );
    } else {
      const e = inverse.mulPosition(this.eye).sub(sphere.center),
        d0 = u0.sub(e.multiplyScalar(h0)),
        dd = u1.sub(e.multiplyScalar(h1)).sub(d0);
      const c0 = e.cross(d0),
        dc = e.cross(dd);
      // Cross-product form avoids subtracting two large squared distances.
      addRoots(
        r2 * dd.dot(dd) - dc.dot(dc),
        2 * (r2 * d0.dot(dd) - c0.dot(dc)),
        r2 * d0.dot(d0) - c0.dot(c0),
      );
    }
    const im = this.matrix.inverse();
    const near = (p: Vector) => {
      const c = clip4(new Vector(p.x, p.y, -1), im),
        h = c[3];
      const m = inverse;
      return {
        u: new Vector(
          m.x00 * c[0] +
            m.x01 * c[1] +
            m.x02 * c[2] +
            m.x03 * h -
            sphere.center.x * h,
          m.x10 * c[0] +
            m.x11 * c[1] +
            m.x12 * c[2] +
            m.x13 * h -
            sphere.center.y * h,
          m.x20 * c[0] +
            m.x21 * c[1] +
            m.x22 * c[2] +
            m.x23 * h -
            sphere.center.z * h,
        ),
        h,
      };
    };
    const n0 = near(pa),
      n1 = near(pb);
    sphereRoots(n0.u, n1.u, n0.h, n1.h);
    // On sphere-owned polylines the chord approximates a surface arc. Split at
    // the analytic silhouette, not at the chord's artificial interior contacts.
    if (owner === record.owner) {
      const e = inverse.mulPosition(this.eye).sub(sphere.center);
      if (this.options.orthographic) {
        const d = this.options.direction!,
          m = inverse;
        const ld = new Vector(
          m.x00 * d.x + m.x01 * d.y + m.x02 * d.z,
          m.x10 * d.x + m.x11 * d.y + m.x12 * d.z,
          m.x20 * d.x + m.x21 * d.y + m.x22 * d.z,
        );
        const f0 = u0.dot(ld),
          f1 = u1.dot(ld);
        if (f0 !== f1) roots.push(-f0 / (f1 - f0));
      } else {
        const du = u1.sub(u0),
          dh = h1 - h0;
        addRoots(
          du.dot(e) * dh - du.dot(du),
          u0.dot(e) * dh + du.dot(e) * h0 - 2 * u0.dot(du),
          u0.dot(e) * h0 - u0.dot(u0),
        );
      }
    }
    roots.sort((a, b) => a - b);
    for (let i = 1; i < roots.length; i++) {
      const lo = Math.max(0, roots[i - 1]),
        hi = Math.min(1, roots[i]);
      if (!(lo < hi)) continue;
      const t = (lo + hi) / 2,
        parameter = (t * wa) / ((1 - t) * wb + t * wa),
        p = a.add(b.sub(a).multiplyScalar(parameter));
      const d = this.options.orthographic
        ? this.options.direction!
        : this.eye.sub(p).normalize();
      if (owner === record.owner) {
        const local = inverse.mulPosition(p).sub(sphere.center),
          m = inverse;
        const ld = new Vector(
          m.x00 * d.x + m.x01 * d.y + m.x02 * d.z,
          m.x10 * d.x + m.x11 * d.y + m.x12 * d.z,
          m.x20 * d.x + m.x21 * d.y + m.x22 * d.z,
        );
        if (local.dot(ld) < 0) out.push([lo, hi]);
        continue;
      }
      const ray = new Ray(p, d),
        c = clip4(p, this.matrix),
        q = clip4(p.add(d), this.matrix),
        slope = q[2] + q[3] - c[2] - c[3];
      const max = slope < 0 ? -(c[2] + c[3]) / slope : Infinity;
      const hit = world.intersect(ray, rayEpsilon(ray), max);
      if (hit.ok() && hit.t < max) out.push([lo, hi]);
    }
  }
  private fallbackIntervals(
    a: Vector,
    b: Vector,
    pa: Vector,
    pb: Vector,
    out: Interval[],
  ) {
    const length = Math.hypot(
      ((pb.x - pa.x) * this.width) / 2,
      ((pb.y - pa.y) * this.height) / 2,
    );
    const count = Math.max(
      2,
      Math.ceil(length / (this.options.fallbackSpacing ?? 0.5)),
    );
    const wa = clip4(a, this.matrix)[3],
      wb = clip4(b, this.matrix)[3];
    const world = (t: number) => {
      const u = (t * wa) / ((1 - t) * wb + t * wa);
      return a.add(b.sub(a).multiplyScalar(u));
    };
    const hidden = (t: number) => {
      if (++this.stats.fallbackRays > (this.options.maxTests ?? 20000000))
        throw new Error("Fallback visibility budget exceeded");
      const p = world(t),
        d = this.options.orthographic
          ? this.options.direction!
          : this.eye.sub(p).normalize();
      const ray = new Ray(p, d);
      // Stop at near plane, not at an arbitrary eye distance in orthographic views.
      const c = clip4(p, this.matrix),
        q = clip4(p.add(d), this.matrix);
      const slope = q[2] + q[3] - c[2] - c[3];
      const max = slope < 0 ? -(c[2] + c[3]) / slope : Infinity;
      return this.fallback.some((s) => {
        if (s.occluded) return s.occluded(ray, rayEpsilon(ray), max);
        const h = s.intersect(ray, rayEpsilon(ray), max);
        return h.ok() && h.t > rayEpsilon(ray) && h.t < max;
      });
    };
    let before = hidden(0),
      start = before ? 0 : -1;
    for (let i = 1; i <= count; i++) {
      const t = i / count,
        state = hidden(t);
      if (state !== before) {
        let lo = (i - 1) / count,
          hi = t;
        for (
          let j = 0;
          j < 40 &&
          (hi - lo) * length > (this.options.curveTolerance ?? 0.25) / 4;
          j++
        ) {
          const mid = (lo + hi) / 2;
          if (hidden(mid) === before) lo = mid;
          else hi = mid;
        }
        const edge = (lo + hi) / 2;
        if (state) start = edge;
        else out.push([start, edge]);
      }
      before = state;
    }
    if (before) out.push([start, 1]);
  }
}

export function boxTriangles(box: Cube): Triangle[] {
  const a = box.min,
    b = box.max,
    p = [
      new Vector(a.x, a.y, a.z),
      new Vector(b.x, a.y, a.z),
      new Vector(b.x, b.y, a.z),
      new Vector(a.x, b.y, a.z),
      new Vector(a.x, a.y, b.z),
      new Vector(b.x, a.y, b.z),
      new Vector(b.x, b.y, b.z),
      new Vector(a.x, b.y, b.z),
    ];
  return [
    [0, 3, 2, 1],
    [4, 5, 6, 7],
    [0, 1, 5, 4],
    [3, 7, 6, 2],
    [0, 4, 7, 3],
    [1, 2, 6, 5],
  ].flatMap(([a, b, c, d]) => [
    new Triangle(p[a], p[b], p[c]),
    new Triangle(p[a], p[c], p[d]),
  ]);
}
function roundTriangles(
  shape: Sphere | Cylinder | Cone,
  n: number,
): Triangle[] {
  const out: Triangle[] = [];
  if (shape instanceof Sphere) {
    const rows = Math.ceil(n / 2),
      point = (i: number, j: number) => {
        const lat = -Math.PI / 2 + (i * Math.PI) / rows,
          lng = ((j % n) * 2 * Math.PI) / n;
        return shape.center.add(
          new Vector(
            Math.cos(lat) * Math.cos(lng),
            Math.cos(lat) * Math.sin(lng),
            Math.sin(lat),
          ).multiplyScalar(shape.radius),
        );
      };
    for (let i = 0; i < rows; i++)
      for (let j = 0; j < n; j++) {
        const a = point(i, j),
          b = point(i, j + 1),
          c = point(i + 1, j + 1),
          d = point(i + 1, j);
        if (i > 0) out.push(new Triangle(a, b, c));
        if (i < rows - 1) out.push(new Triangle(a, c, d));
      }
  } else {
    const z0 = shape instanceof Cylinder ? shape.z0 : 0,
      z1 = shape instanceof Cylinder ? shape.z1 : shape.height;
    for (let j = 0; j < n; j++) {
      const p = (i: number, z: number) =>
        new Vector(
          shape.radius * Math.cos((i * 2 * Math.PI) / n),
          shape.radius * Math.sin((i * 2 * Math.PI) / n),
          z,
        );
      const a = p(j, z0),
        b = p(j + 1, z0),
        c = p(j + 1, z1),
        d = p(j, z1),
        top = new Vector(0, 0, z1),
        bottom = new Vector(0, 0, z0);
      out.push(new Triangle(bottom, b, a));
      if (shape instanceof Cylinder)
        out.push(
          new Triangle(a, b, c),
          new Triangle(a, c, d),
          new Triangle(top, d, c),
        );
      else out.push(new Triangle(a, b, top));
    }
  }
  return out;
}

/** Clip, hide, and project paths without reconnecting across invisible intervals. */
export function renderPaths(
  paths: Vector[][],
  matrix: Matrix,
  width: number,
  height: number,
  visibility?: Visibility,
  maxVertices = 2000000,
): Vector[][] {
  const output: Vector[][] = [];
  let vertices = 0;
  const screen = (p: Vector) =>
    new Vector(((p.x + 1) * width) / 2, ((p.y + 1) * height) / 2, 0);
  for (const path of paths) {
    let stroke: Vector[] = [];
    const flush = () => {
      if (stroke.length > 1) output.push(stroke);
      stroke = [];
    };
    for (let i = 1; i < path.length; i++) {
      const clipped = clipSegment(path[i - 1], path[i], matrix);
      if (!clipped) {
        flush();
        continue;
      }
      const [a, b] = clipped,
        pa = matrix.mulPositionW(a),
        pb = matrix.mulPositionW(b);
      const runs = visibility
        ? visibility.visible(
            a,
            b,
            visibility.scene.pathOwners.get(path),
            pathSources.get(path),
          )
        : ([[0, 1]] as Interval[]);
      if (!runs.length) {
        flush();
        continue;
      }
      for (const [lo, hi] of runs) {
        const start = screen(pa.add(pb.sub(pa).multiplyScalar(lo))),
          end = screen(pa.add(pb.sub(pa).multiplyScalar(hi)));
        if (!Number.isFinite(start.x + start.y + end.x + end.y)) {
          flush();
          continue;
        }
        const last = stroke[stroke.length - 1];
        if (lo > 0 || !last || last.distance(start) > 1e-8) {
          flush();
          stroke.push(start);
        }
        if (start.distance(end) > 1e-12) {
          const prev = stroke[stroke.length - 2],
            tail = stroke[stroke.length - 1];
          if (
            prev &&
            Math.abs(
              cross(
                tail.x - prev.x,
                tail.y - prev.y,
                end.x - tail.x,
                end.y - tail.y,
              ),
            ) < 1e-10 &&
            (tail.x - prev.x) * (end.x - tail.x) +
              (tail.y - prev.y) * (end.y - tail.y) >=
              0
          )
            stroke[stroke.length - 1] = end;
          else stroke.push(end);
        }
        if ((vertices += 2) > maxVertices)
          throw new Error("Projected vertex budget exceeded");
        if (hi < 1) flush();
      }
    }
    flush();
  }
  return output;
}
