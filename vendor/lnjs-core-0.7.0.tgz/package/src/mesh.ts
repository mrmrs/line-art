import { rayEpsilon, quadratic } from "./numeric";
import { ShapeT } from "./shape";
import { Box, boxForShapes } from "./box";
import Triangle from "./triangle";
import { Tree } from "./tree";
import Vector from "./vector";
import Cube from "./cube";
import Ray from "./ray";
import Hit from "./hit";
import { Paths } from "./paths";
import { translate, identity } from "./matrix";
import Plane from "./plane";
import { HashSet } from "./set";
import { Matrix } from "./matrix";

export default class Mesh implements ShapeT {
  box: Box;
  triangles: Triangle[];
  tree: Tree;
  dirty: boolean;

  constructor(triangles: Triangle[]) {
    let box = boxForShapes(triangles);
    this.box = box;
    this.triangles = triangles;
    this.tree = new Tree(triangles);
    this.dirty = false;
  }

  compile() {
    if (this.dirty) {
      this.tree = new Tree(this.triangles);
      this.dirty = false;
    }
  }

  boundingBox(): Box {
    return this.box;
  }

  contains(v: Vector, f: number): boolean {
    if (!this.box.contains(v)) return false;
    // Closed, consistently represented meshes only. One non-axis-aligned ray,
    // nearest hits counted once even where adjacent triangles share an edge.
    const r = new Ray(
      v,
      new Vector(1, 0.3713906763541037, 0.5291502622129182).normalize(),
    );
    let cursor = rayEpsilon(r),
      count = 0;
    for (let i = 0; i <= this.triangles.length; i++) {
      const h = this.intersect(r, cursor);
      if (!h.ok()) return count % 2 === 1;
      count++;
      cursor =
        h.t + Math.max(Math.abs(h.t) * 64 * Number.EPSILON, rayEpsilon(r));
    }
    throw new Error("Mesh containment crossing budget exceeded");
  }

  intersect(r: Ray, tMin = rayEpsilon(r), tMax = Infinity): Hit {
    this.compile();
    return this.tree.intersect(r, tMin, tMax);
  }
  occluded(r: Ray, tMin: number, tMax: number): boolean {
    this.compile();
    return this.tree.occluded(r, tMin, tMax);
  }

  paths(
    options: {
      mode?: "all" | "creases" | "silhouette";
      creaseAngle?: number;
      eye?: Vector;
      direction?: Vector;
    } = {},
  ): Paths {
    const edges = new Map<
      string,
      { a: Vector; b: Vector; normals: Vector[] }
    >();
    const key = (v: Vector) => `${v.x},${v.y},${v.z}`;
    for (const t of this.triangles) {
      const normal = t.v2.sub(t.v1).cross(t.v3.sub(t.v1)).normalize();
      const p = [t.v1, t.v2, t.v3];
      for (let i = 0; i < 3; i++) {
        const a = p[i],
          b = p[(i + 1) % 3],
          ka = key(a),
          kb = key(b),
          k = ka < kb ? `${ka}|${kb}` : `${kb}|${ka}`;
        const edge = edges.get(k);
        if (edge) edge.normals.push(normal);
        else edges.set(k, { a, b, normals: [normal] });
      }
    }
    const result: Paths = [],
      mode = options.mode ?? "all",
      cos = Math.cos(((options.creaseAngle ?? 30) * Math.PI) / 180);
    for (const { a, b, normals } of edges.values()) {
      let include = mode === "all" || normals.length !== 2;
      if (!include && mode === "creases")
        include = normals[0].dot(normals[1]) < cos;
      if (!include && mode === "silhouette") {
        const d =
          options.direction ?? options.eye?.sub(a.add(b).multiplyScalar(0.5));
        if (!d)
          throw new Error(
            "Silhouette edges require an eye or camera direction",
          );
        include = normals[0].dot(d) >= 0 !== normals[1].dot(d) >= 0;
      }
      if (include) result.push([a, b]);
    }
    return result;
  }

  updateBoundingBox(): void {
    this.box = boxForShapes(this.triangles);
  }

  unitCube(): void {
    this.fitInside(
      new Box(new Vector(0, 0, 0), new Vector(1, 1, 1)),
      new Vector(0, 0, 0),
    );
    this.moveTo(new Vector(0, 0, 0), new Vector(0.5, 0.5, 0.5));
  }

  moveTo(position: Vector, anchor: Vector): void {
    let matrix = translate(position.sub(this.box.anchor(anchor)));
    this.transform(matrix);
  }

  fitInside(box: Box, anchor: Vector): void {
    let scale = box.size().div(this.boundingBox().size()).minComponent();
    let extra = box.size().sub(this.boundingBox().size().multiplyScalar(scale));
    let matrix = identity();
    matrix = matrix.translate(this.boundingBox().min.multiplyScalar(-1));
    matrix = matrix.scale(new Vector(scale, scale, scale));
    matrix = matrix.translate(box.min.add(extra.mul(anchor)));
    this.transform(matrix);
  }

  transform(matrix: Matrix): void {
    for (const t of this.triangles) {
      t.v1 = matrix.mulPosition(t.v1);
      t.v2 = matrix.mulPosition(t.v2);
      t.v3 = matrix.mulPosition(t.v3);
      t.updateBoundingBox();
    }
    this.updateBoundingBox();
    this.dirty = true; // dirty
  }

  saveBinarySTL(path: string): Error {
    // TODO
    return new Error();
  }

  voxelize(size: number): Cube[] {
    let z1 = this.box.min.z;
    let z2 = this.box.max.z;
    let set: HashSet<Vector> = new HashSet();
    for (let z = z1; z <= z2; z += size) {
      let plane = new Plane(new Vector(0, 0, z), new Vector(0, 0, 1));
      let paths = plane.intersectMesh(this);
      for (const path of paths) {
        for (const v of path) {
          let x = Math.floor(v.x / size + 0.5) * size;
          let y = Math.floor(v.y / size + 0.5) * size;
          let z = Math.floor(v.z / size + 0.5) * size;
          const vec = new Vector(x, y, z);
          set.add(vec);
        }
      }
    }
    let result: Cube[] = [];
    set.forEach((v) => {
      let cube = new Cube(v.subScalar(size / 2), v.addScalar(size / 2));
      result.push(cube);
    });
    return result;
  }
}
