import { rayEpsilon, quadratic } from "./numeric";
import Vector from "./vector";
import { Box } from "./box";
import { ShapeT } from "./shape";
import Hit, { NoHit } from "./hit";
import Ray from "./ray";
import { Paths } from "./paths";

export default class Cube implements ShapeT {
  min: Vector;
  max: Vector;
  box: Box;
  constructor(min: Vector, max: Vector) {
    this.min = min;
    this.max = max;
    this.box = new Box(min, max);
  }

  compile() {
    // noop
  }

  boundingBox(): Box {
    return this.box;
  }

  contains(v: Vector, f: number): boolean {
    if (v.x < this.min.x - f || v.x > this.max.x + f) {
      return false;
    }
    if (v.y < this.min.y - f || v.y > this.max.y + f) {
      return false;
    }
    if (v.z < this.min.z - f || v.z > this.max.z + f) {
      return false;
    }
    return true;
  }

  intersect(r: Ray, tMin = rayEpsilon(r), tMax = Infinity): Hit {
    const [a, b] = this.box.intersect(r);
    if (a > b) return NoHit;
    const t = a > tMin ? a : b;
    return t > tMin && t < tMax ? new Hit(this, t) : NoHit;
  }

  paths(): Paths {
    let [x1, y1, z1] = [this.min.x, this.min.y, this.min.z];
    let [x2, y2, z2] = [this.max.x, this.max.y, this.max.z];
    return [
      [new Vector(x1, y1, z1), new Vector(x1, y1, z2)],
      [new Vector(x1, y1, z1), new Vector(x1, y2, z1)],
      [new Vector(x1, y1, z1), new Vector(x2, y1, z1)],
      [new Vector(x1, y1, z2), new Vector(x1, y2, z2)],
      [new Vector(x1, y1, z2), new Vector(x2, y1, z2)],
      [new Vector(x1, y2, z1), new Vector(x1, y2, z2)],
      [new Vector(x1, y2, z1), new Vector(x2, y2, z1)],
      [new Vector(x1, y2, z2), new Vector(x2, y2, z2)],
      [new Vector(x2, y1, z1), new Vector(x2, y1, z2)],
      [new Vector(x2, y1, z1), new Vector(x2, y2, z1)],
      [new Vector(x2, y1, z2), new Vector(x2, y2, z2)],
      [new Vector(x2, y2, z1), new Vector(x2, y2, z2)],
    ];
  }
}
