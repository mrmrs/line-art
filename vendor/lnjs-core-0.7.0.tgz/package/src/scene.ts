import { Visibility, VisibilityOptions, renderPaths } from "./visibility";
import { rayEpsilon } from "./numeric";
import { ShapeFilter } from "./tree";
import { ShapeT } from "./shape";
import { Tree } from "./tree";
import Ray from "./ray";
import Hit from "./hit";
import Vector from "./vector";
import { Paths as PathsT } from "./paths";
import * as Paths from "./paths";
import { lookAt, Matrix, translate } from "./matrix";
import { ClipFilter } from "./filter";

export default class Scene {
  shapes: Array<ShapeT>;
  tree: Tree;
  readonly pathOwners = new WeakMap<Vector[], ShapeT>();

  constructor() {
    this.shapes = [];
    this.tree = new Tree(this.shapes);
  }

  compile() {
    for (const shape of this.shapes) {
      shape.compile();
    }
    this.tree = new Tree(this.shapes);
  }

  add(shape: ShapeT) {
    this.shapes.push(shape);
  }

  intersect(ray: Ray, tMin = rayEpsilon(ray), tMax = Infinity): Hit {
    return this.tree.intersect(ray, tMin, tMax);
  }

  occluded(
    ray: Ray,
    tMin = rayEpsilon(ray),
    tMax = Infinity,
    filter?: ShapeFilter,
  ): boolean {
    return this.tree.occluded(ray, tMin, tMax, filter);
  }

  visible(eye: Vector, point: Vector): boolean {
    const v = eye.sub(point);
    const r = new Ray(point, v.normalize());
    return !this.occluded(r, rayEpsilon(r), v.length());
  }

  paths(): PathsT {
    let results: PathsT = [];
    for (const shape of this.shapes) {
      let shapePaths = shape.paths();
      shapePaths.forEach((p) => {
        this.pathOwners.set(p, shape);
        results.push(p);
      });
    }
    return results;
  }

  render(
    eye: Vector,
    center: Vector,
    up: Vector,
    width: number,
    height: number,
    fovy: number,
    near: number,
    far: number,
    step: number,
  ): PathsT {
    let aspect = width / height;
    let matrix = lookAt(eye, center, up);
    matrix = matrix.perspective(fovy, aspect, near, far);
    return this.renderWithMatrix(matrix, eye, width, height, step);
  }

  renderWithMatrix(
    matrix: Matrix,
    eye: Vector,
    width: number,
    height: number,
    step: number,
    options: VisibilityOptions = {},
  ): PathsT {
    this.compile();
    const orthographic =
      matrix.x30 === 0 && matrix.x31 === 0 && matrix.x32 === 0;
    const inverse = matrix.inverse();
    const direction = inverse
      .mulPositionW(new Vector(0, 0, -1))
      .sub(inverse.mulPositionW(new Vector(0, 0, 1)))
      .normalize();
    const visibility = new Visibility(this, matrix, eye, width, height, {
      orthographic,
      direction,
      ...options,
    });
    return renderPaths(this.paths(), matrix, width, height, visibility);
  }
}
