import { pathSources } from "./path-source";
import { identity } from "./matrix";
import type Triangle from "./triangle";
import { rayEpsilon, quadratic } from "./numeric";
import { Box } from "./box";
import Vector from "./vector";
import Ray from "./ray";
import Hit, { NoHit } from "./hit";
import { Paths as PathsT } from "./paths";
import * as Paths from "./paths";
import { Matrix } from "./matrix";

export interface ShapeT {
  compile(): void;
  boundingBox(): Box;
  contains(v: Vector, point: number): boolean;
  intersect(r: Ray, tMin?: number, tMax?: number): Hit;
  occluded?(r: Ray, tMin: number, tMax: number): boolean;
  paths(): PathsT;
  /** Optional surface representation for continuous hidden-line clipping. */
  occlusionTriangles?(): Triangle[];
  /** Delegating wrappers expose their occluding shape without adding paths. */
  occlusionShape?: ShapeT;
}

export class TransformedShape implements ShapeT {
  shape: ShapeT;
  matrix: Matrix;
  inverse: Matrix;
  constructor(shape: ShapeT, matrix: Matrix) {
    this.shape = shape;
    this.matrix = matrix;
    this.inverse = matrix.inverse();
    if (
      !Number.isFinite(
        this.inverse.x00 +
          this.inverse.x11 +
          this.inverse.x22 +
          this.inverse.x33,
      )
    )
      throw new Error("Shape transform must be invertible");
  }

  compile() {
    this.shape.compile();
  }

  boundingBox(): Box {
    return this.matrix.mulBox(this.shape.boundingBox());
  }

  contains(v: Vector, f: number): boolean {
    return this.shape.contains(this.inverse.mulPosition(v), f);
  }

  intersect(r: Ray, tMin = rayEpsilon(r), tMax = Infinity): Hit {
    const origin = this.inverse.mulPosition(r.origin);
    // Multiply only the linear part: subtraction of large translated points loses precision.
    const m = this.inverse,
      d = r.direction;
    const direction = new Vector(
      m.x00 * d.x + m.x01 * d.y + m.x02 * d.z,
      m.x10 * d.x + m.x11 * d.y + m.x12 * d.z,
      m.x20 * d.x + m.x21 * d.y + m.x22 * d.z,
    );
    const k = direction.length();
    if (!(k > 0) || !Number.isFinite(k)) return NoHit;
    const hit = this.shape.intersect(
      new Ray(origin, direction.divScalar(k)),
      tMin * k,
      tMax * k,
    );
    return hit.ok() ? new Hit(this, hit.t / k) : NoHit;
  }

  occluded(r: Ray, tMin: number, tMax: number): boolean {
    const m = this.inverse,
      d = r.direction;
    const direction = new Vector(
      m.x00 * d.x + m.x01 * d.y + m.x02 * d.z,
      m.x10 * d.x + m.x11 * d.y + m.x12 * d.z,
      m.x20 * d.x + m.x21 * d.y + m.x22 * d.z,
    );
    const k = direction.length();
    if (!(k > 0) || !Number.isFinite(k)) return false;
    const local = new Ray(m.mulPosition(r.origin), direction.divScalar(k));
    if (this.shape.occluded)
      return this.shape.occluded(local, tMin * k, tMax * k);
    const h = this.shape.intersect(local, tMin * k, tMax * k);
    return h.ok() && h.t > tMin * k && h.t < tMax * k;
  }

  paths(): PathsT {
    const paths = this.shape.paths();
    for (const path of paths)
      if (!pathSources.has(path))
        pathSources.set(path, { shape: this.shape, matrix: identity() });
    return Paths.transform(paths, this.matrix);
  }
}

export class EmptyShape implements ShapeT {
  compile() {
    // noop
  }
  boundingBox() {
    let min = new Vector(0, 0, 0);
    let max = new Vector(0, 0, 0);
    return new Box(min, max);
  }

  contains(v: Vector, f: number): boolean {
    return false;
  }

  intersect(r: Ray): Hit {
    return NoHit;
  }

  paths() {
    return [];
  }
}
