import { ShapeT, EmptyShape } from "./shape";
import { FilterT } from "./filter";
import Vector from "./vector";
import Ray from "./ray";
import Hit, { NoHit } from "./hit";
import { after, rayEpsilon } from "./numeric";
import { Paths } from "./paths";
import { Solid } from "./solid";
import { pathSources } from "./path-source";
import { identity } from "./matrix";

export enum CSGOperation {
  Intersection,
  Difference,
  Union,
}

export class BooleanShape implements ShapeT, FilterT {
  op: CSGOperation;
  a: ShapeT;
  b: ShapeT;

  static create(op: CSGOperation, ...shapes: ShapeT[]): ShapeT {
    if (shapes.length === 0) {
      return new EmptyShape();
    }
    let shape = shapes[0];
    for (let i = 1; i < shapes.length; i++) {
      shape = new BooleanShape(op, shape, shapes[i]);
    }
    return shape;
  }

  constructor(op: CSGOperation, a: ShapeT, b: ShapeT) {
    this.op = op;
    this.a = a;
    this.b = b;
  }

  compile() {
    this.a.compile();
    this.b.compile();
  }

  boundingBox() {
    let a = this.a.boundingBox();
    let b = this.b.boundingBox();
    return a.extend(b);
  }

  contains(v: Vector, f: number): boolean {
    switch (this.op) {
      case CSGOperation.Union:
        return this.a.contains(v, f) || this.b.contains(v, f);
      case CSGOperation.Intersection:
        return this.a.contains(v, f) && this.b.contains(v, f);
      case CSGOperation.Difference:
        return this.a.contains(v, f) && !this.b.contains(v, -f);
    }
    return false;
  }

  intersect(r: Ray, tMin = rayEpsilon(r), tMax = Infinity): Hit {
    // Keep one ray parameterization throughout; never step the origin by a fixed gap.
    let cursor = tMin;
    let inside = this.contains(r.position(after(cursor)), 0);
    for (let i = 0; i < 100000; i++) {
      const h = this.a
        .intersect(r, cursor, tMax)
        .min(this.b.intersect(r, cursor, tMax));
      if (!h.ok() || h.t >= tMax) return NoHit;
      const next = after(h.t);
      const state = this.contains(r.position(next), 0);
      if (state !== inside) return new Hit(this, h.t);
      inside = state;
      cursor = next;
    }
    throw new Error("Boolean boundary budget exceeded");
  }

  paths() {
    const a = new Solid(this.a),
      b = new Solid(this.b),
      solid = new Solid(this),
      output: Paths = [];
    const trim = (shape: ShapeT, other: Solid, fromB: boolean) => {
      const paths = shape.paths();
      for (const path of paths) {
        const source = pathSources.get(path) ?? { shape, matrix: identity() };
        let run: Vector[] = [];
        const flush = () => {
          if (run.length > 1) {
            output.push(run);
            pathSources.set(run, source);
          }
          run = [];
        };
        for (let i = 1; i < path.length; i++) {
          const start = path[i - 1],
            delta = path[i].sub(start);
          const cuts = other.cuts(start, path[i]);
          for (let j = 1; j < cuts.length; j++) {
            const lo = cuts[j - 1],
              hi = cuts[j],
              p = start.add(delta.multiplyScalar((lo + hi) / 2));
            let keep =
              this.op === CSGOperation.Intersection ||
              (this.op === CSGOperation.Difference && fromB)
                ? other.contains(p, true)
                : !other.contains(p, this.op === CSGOperation.Difference);
            const sharedCurve = other.coincidentSource(source, p);
            if (sharedCurve) keep = solid.boundary(sharedCurve, delta);
            else if (
              keep &&
              other.contains(p, true) !== other.contains(p, false)
            )
              keep = solid.boundary(p, delta);
            if (keep) {
              if (!run.length) run.push(start.add(delta.multiplyScalar(lo)));
              run.push(start.add(delta.multiplyScalar(hi)));
            } else flush();
          }
        }
        flush();
      }
    };
    trim(this.a, b, false);
    trim(this.b, a, true);
    const seen = new Set<string>();
    return output.filter((path) => {
      const vertices = path.map((p) => `${p.x},${p.y},${p.z}`);
      const forward = vertices.join(";"),
        reverse = vertices.reverse().join(";");
      const key = forward < reverse ? forward : reverse;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  filter(v: Vector): [Vector, boolean] {
    return [v, this.contains(v, 0)];
  }
}
