import { quadratic } from "./numeric";
// Ascending coefficients. The Boolean arrangement only requires degree <= 4.
export type Polynomial = number[];
export const add = (a: Polynomial, b: Polynomial): Polynomial =>
  Array.from(
    { length: Math.max(a.length, b.length) },
    (_, i) => (a[i] ?? 0) + (b[i] ?? 0),
  );
export const scale = (a: Polynomial, k: number): Polynomial =>
  a.map((x) => x * k);
export const sub = (a: Polynomial, b: Polynomial): Polynomial =>
  add(a, scale(b, -1));
export function mul(a: Polynomial, b: Polynomial): Polynomial {
  const c = new Array(a.length + b.length - 1).fill(0);
  a.forEach((x, i) => b.forEach((y, j) => (c[i + j] += x * y)));
  return c;
}
export function evaluate(a: Polynomial, x: number): number {
  let y = 0;
  for (let i = a.length - 1; i >= 0; i--) y = y * x + a[i];
  return y;
}
export function unique(values: number[]): number[] {
  values.sort((a, b) => a - b);
  return values.filter(
    (v, i) =>
      !i || v - values[i - 1] > 8 * Number.EPSILON * Math.max(1, Math.abs(v)),
  );
}
/** Isolate real roots between derivative roots (monotone cells), including tangencies. */
export function roots(coefficients: Polynomial, lo = 0, hi = 1): number[] {
  const a = coefficients.slice();
  while (a.length && a[a.length - 1] === 0) a.pop();
  if (a.length < 2) return [];
  const norm = Math.max(...a.map(Math.abs));
  if (!Number.isFinite(norm))
    throw new Error("Non-finite Boolean boundary polynomial");
  for (let i = 0; i < a.length; i++) a[i] /= norm;
  if (a.length === 2) {
    const x = -a[0] / a[1];
    return x >= lo && x <= hi ? [x] : [];
  }
  if (a.length === 3)
    return unique(
      quadratic(a[2], a[1], a[0]).filter((x) => x >= lo && x <= hi),
    );
  const stops = [
    lo,
    ...roots(
      a.slice(1).map((v, i) => v * (i + 1)),
      lo,
      hi,
    ),
    hi,
  ];
  const out: number[] = [];
  for (const x of stops) {
    const error = 16 * Number.EPSILON * evaluate(a.map(Math.abs), Math.abs(x));
    if (Math.abs(evaluate(a, x)) <= error) out.push(x);
  }
  for (let i = 1; i < stops.length; i++) {
    let l = stops[i - 1],
      r = stops[i],
      fl = evaluate(a, l),
      fr = evaluate(a, r);
    if (fl < 0 === fr < 0 || fl === 0 || fr === 0) continue;
    for (let j = 0; j < 80; j++) {
      const m = l + (r - l) / 2;
      if (m === l || m === r) break;
      const fm = evaluate(a, m);
      if (fm === 0) {
        l = r = m;
        break;
      }
      if (fm < 0 === fl < 0) {
        l = m;
        fl = fm;
      } else {
        r = m;
        fr = fm;
      }
    }
    out.push(l + (r - l) / 2);
  }
  return unique(out);
}
