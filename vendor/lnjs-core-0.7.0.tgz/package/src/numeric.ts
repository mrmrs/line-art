import Ray from "./ray";

// Ray-parameter uncertainty, scaled to the input coordinates and direction.
export function rayEpsilon(r: Ray): number {
  const scale = Math.max(
    Math.abs(r.origin.x),
    Math.abs(r.origin.y),
    Math.abs(r.origin.z),
    1e-100,
  );
  return (64 * Number.EPSILON * scale) / Math.max(r.direction.length(), 1e-100);
}
export function after(t: number): number {
  return t + Math.max(Math.abs(t) * 16 * Number.EPSILON, Number.MIN_VALUE);
}
// Stable quadratic roots; includes the linear and double-root cases.
export function quadratic(a: number, b: number, c: number): number[] {
  if (a === 0) return b === 0 ? [] : [-c / b];
  const d = b * b - 4 * a * c;
  if (d < 0) return [];
  const s = Math.sqrt(d);
  const q = -0.5 * (b + (b < 0 ? -s : s));
  if (q === 0) return [-b / (2 * a)];
  return [q / a, c / q].sort((x, y) => x - y);
}
