import Ray from "./ray";
import { ShapeT } from "./shape";
import Vector from "./vector";
import { Axis } from "./axis";
import Triangle from "./triangle";

export type PointPair = [number, number];

export class Box {
  min: Vector;
  max: Vector;

  constructor(min?: Vector, max?: Vector) {
    // TODO is this right? Does it default to 0, 0, 0?
    this.min = min || new Vector(0, 0, 0);
    this.max = max || new Vector(0, 0, 0);
  }

  anchor(anchor: Vector): Vector {
    return this.min.add(this.size().mul(anchor));
  }

  center(): Vector {
    return this.anchor(new Vector(0.5, 0.5, 0.5));
  }

  size(): Vector {
    return this.max.sub(this.min);
  }

  contains(b: Vector): boolean {
    let { min, max } = this;
    return (
      min.x <= b.x &&
      max.x >= b.x &&
      min.y <= b.y &&
      max.y >= b.y &&
      min.z <= b.z &&
      max.z >= b.z
    );
  }

  extend(b: Box): Box {
    let min = this.min.min(b.min);
    let max = this.max.max(b.max);
    return new Box(min, max);
  }

  intersect(
    r: Ray,
    tMin = -Infinity,
    tMax = Infinity,
    result: [number, number] = [0, 0],
  ): [number, number] {
    const o = r.origin,
      d = r.direction,
      min = this.min,
      max = this.max;
    if (!Number.isFinite(o.x + o.y + o.z + d.x + d.y + d.z)) {
      result[0] = Infinity;
      result[1] = -Infinity;
      return result;
    }
    if (d.x === 0) {
      if (o.x < min.x || o.x > max.x) {
        result[0] = Infinity;
        result[1] = -Infinity;
        return result;
      }
    } else {
      const a = (min.x - o.x) / d.x,
        b = (max.x - o.x) / d.x;
      tMin = Math.max(tMin, Math.min(a, b));
      tMax = Math.min(tMax, Math.max(a, b));
    }
    if (d.y === 0) {
      if (o.y < min.y || o.y > max.y) {
        result[0] = Infinity;
        result[1] = -Infinity;
        return result;
      }
    } else {
      const a = (min.y - o.y) / d.y,
        b = (max.y - o.y) / d.y;
      tMin = Math.max(tMin, Math.min(a, b));
      tMax = Math.min(tMax, Math.max(a, b));
    }
    if (d.z === 0) {
      if (o.z < min.z || o.z > max.z) {
        result[0] = Infinity;
        result[1] = -Infinity;
        return result;
      }
    } else {
      const a = (min.z - o.z) / d.z,
        b = (max.z - o.z) / d.z;
      tMin = Math.max(tMin, Math.min(a, b));
      tMax = Math.min(tMax, Math.max(a, b));
    }
    result[0] = tMin;
    result[1] = tMax;
    return result;
  }

  partition(axis: Axis, point: number): [boolean, boolean] {
    switch (axis) {
      case Axis.AxisX: {
        let left = this.min.x <= point;
        let right = this.max.x >= point;
        return [left, right];
      }
      case Axis.AxisY: {
        let left = this.min.y <= point;
        let right = this.max.y >= point;
        return [left, right];
      }
      case Axis.AxisZ: {
        let left = this.min.z <= point;
        let right = this.max.z >= point;
        return [left, right];
      }
    }
    throw new Error(`Partitioning NoAxis`);
  }
}

export function boxForShapes(shapes: Array<ShapeT>): Box {
  if (shapes.length === 0) {
    // TODO empty box?
    return new Box();
  }
  let box = shapes[0].boundingBox();
  for (const shape of shapes) {
    box = box.extend(shape.boundingBox());
  }
  return box;
}
