import { ShapeT } from "./shape";
import { Box } from "./box";
import Triangle from "./triangle";
import { Tree } from "./tree";
import Vector from "./vector";
import Cube from "./cube";
import Ray from "./ray";
import Hit from "./hit";
import { Paths } from "./paths";
import { Matrix } from "./matrix";
export default class Mesh implements ShapeT {
    box: Box;
    triangles: Triangle[];
    tree: Tree;
    dirty: boolean;
    constructor(triangles: Triangle[]);
    compile(): void;
    boundingBox(): Box;
    contains(v: Vector, f: number): boolean;
    intersect(r: Ray): Hit;
    paths(): Paths;
    updateBoundingBox(): void;
    unitCube(): void;
    moveTo(position: Vector, anchor: Vector): void;
    fitInside(box: Box, anchor: Vector): void;
    transform(matrix: Matrix): void;
    saveBinarySTL(path: string): Error;
    voxelize(size: number): Cube[];
}
