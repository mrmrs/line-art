import { ShapeT } from "./shape";
import { FilterT } from "./filter";
import Vector from "./vector";
import Ray from "./ray";
import Hit from "./hit";
import * as Paths from "./paths";
export declare enum CSGOperation {
    Intersection = 0,
    Difference = 1,
    Union = 2
}
export declare class BooleanShape implements ShapeT, FilterT {
    op: CSGOperation;
    a: ShapeT;
    b: ShapeT;
    static create(op: CSGOperation, ...shapes: ShapeT[]): ShapeT;
    constructor(op: CSGOperation, a: ShapeT, b: ShapeT);
    compile(): void;
    boundingBox(): import("./box").Box;
    contains(v: Vector, f: number): boolean;
    intersect(r: Ray): Hit;
    paths(): Paths.Paths;
    filter(v: Vector): [Vector, boolean];
}
