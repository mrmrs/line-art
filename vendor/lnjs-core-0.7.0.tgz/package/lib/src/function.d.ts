import { ShapeT } from "./shape";
import { Box } from "./box";
import Vector from "./vector";
import Ray from "./ray";
import Hit from "./hit";
import { Paths } from "./paths";
export declare enum Direction {
    Above = 0,
    Below = 1
}
export type ShapeFn = (x: number, y: number) => number;
export declare class Function implements ShapeT {
    fn: ShapeFn;
    box: Box;
    direction: Direction;
    constructor(fn: ShapeFn, box: Box, direction: Direction);
    compile(): void;
    boundingBox(): Box;
    contains(v: Vector, eps: number): boolean;
    intersect(ray: Ray): Hit;
    paths(): Paths;
}
