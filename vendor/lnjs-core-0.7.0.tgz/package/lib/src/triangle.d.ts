import { ShapeT } from "./shape";
import Vector from "./vector";
import { Box } from "./box";
import Hit from "./hit";
import Ray from "./ray";
import { Paths } from "./paths";
export default class Triangle implements ShapeT {
    v1: Vector;
    v2: Vector;
    v3: Vector;
    box: Box;
    constructor(v1: Vector, v2: Vector, v3: Vector);
    toString(): string;
    calculateBoundingBox(): Box;
    updateBoundingBox(): void;
    compile(): void;
    boundingBox(): Box;
    contains(v: Vector, f: number): boolean;
    intersect(r: Ray): Hit;
    paths(): Paths;
}
