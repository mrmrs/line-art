import { ContourOptions } from "./contours";
import { ShapeT } from "./shape";
import { FilterT } from "./filter";
import Vector from "./vector";
import Ray from "./ray";
import Hit from "./hit";
export declare enum CSGOperation {
    Intersection = 0,
    Difference = 1,
    Union = 2
}
export declare class BooleanShape implements ShapeT, FilterT {
    readonly contourOptions: ContourOptions;
    op: CSGOperation;
    a: ShapeT;
    b: ShapeT;
    static create(op: CSGOperation, ...shapes: ShapeT[]): ShapeT;
    constructor(op: CSGOperation, a: ShapeT, b: ShapeT, contourOptions?: ContourOptions);
    compile(): void;
    boundingBox(): import(".grid-core-0P4OOI/package/src").Box;
    contains(v: Vector, f: number): boolean;
    intersect(r: Ray, tMin?: number, tMax?: number): Hit;
    paths(): import(".grid-core-0P4OOI/package/src/path").Path[];
    filter(v: Vector): [Vector, boolean];
}
