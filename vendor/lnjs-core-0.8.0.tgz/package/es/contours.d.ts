import { BooleanShape } from "./csg";
import { Paths } from "./paths";
export interface ContourOptions {
    /** Generate supported analytic intersection contours (default true). */
    contours?: boolean;
    /** World-space chord deviation target; default 1e-4 of the Boolean extent. */
    contourTolerance?: number;
    /** Maximum newly generated vertices (default 100000). */
    maxContourPoints?: number;
}
/** First analytic contour families; no tessellated approximation of unsupported surface pairs. */
export declare function intersectionContours(shape: BooleanShape, options: ContourOptions): Paths;
