import { PathSource } from "./path-source";
import Vector from "./vector";
import { Matrix } from "./matrix";
import { ShapeT } from "./shape";
type Expression = (p: Vector, inclusive?: boolean) => boolean;
/** Compiled regularized solid. Finite analytic arrangements; no world/pixel stepping. */
export declare class Solid {
    private surfaces;
    readonly contains: Expression;
    private classificationCost;
    private sources;
    private coincidences;
    constructor(shape: ShapeT, transform?: Matrix);
    private compile;
    /** Boundary parameters on a world-space segment; used to trim operand strokes. */
    cuts(a: Vector, b: Vector): number[];
    /** All plane/quadric events on an affine circle, using two bounded rational charts. */
    circleCuts(center: Vector, u: Vector, v: Vector): number[];
    /** Resolve shared curved surfaces before classifying their approximating chords. */
    coincidentSource(source: PathSource, p: Vector): Vector | undefined;
    /** Classify neighboring cells perpendicular to a coincident operand stroke. */
    boundary(p: Vector, tangent: Vector): boolean;
    private neighborhood;
    /** Hidden intervals in world-segment parameter space, clipped at the camera near plane. */
    hidden(a: Vector, b: Vector, matrix: Matrix, eye: Vector, direction: Vector | undefined, charge: (work: number) => void, source?: PathSource): [number, number][];
}
export {};
