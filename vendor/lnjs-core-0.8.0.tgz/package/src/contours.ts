import Vector from "./vector";
import { Matrix, identity } from "./matrix";
import { ShapeT, TransformedShape } from "./shape";
import { BooleanShape } from "./csg";
import Cube from "./cube";
import { Sphere } from "./sphere";
import { Cylinder } from "./cylinder";
import Cone from "./cone";
import { Solid } from "./solid";
import { Paths } from "./paths";
import { PathSource, pathSources } from "./path-source";
import { quadratic } from "./numeric";
import { unique } from "./polynomial";

export interface ContourOptions {
  /** Generate supported analytic intersection contours (default true). */
  contours?: boolean;
  /** World-space chord deviation target; default 1e-4 of the Boolean extent. */
  contourTolerance?: number;
  /** Maximum newly generated vertices (default 100000). */
  maxContourPoints?: number;
}
interface Leaf extends PathSource {
  solid: Solid;
}
interface Plane {
  n: Vector;
  p: Vector;
  leaf: Leaf;
}
const zero = new Vector(0, 0, 0);
const axis = [new Vector(1, 0, 0), new Vector(0, 1, 0), new Vector(0, 0, 1)];
const direction = (m: Matrix, p: Vector) =>
  new Vector(
    m.x00 * p.x + m.x01 * p.y + m.x02 * p.z,
    m.x10 * p.x + m.x11 * p.y + m.x12 * p.z,
    m.x20 * p.x + m.x21 * p.y + m.x22 * p.z,
  );
function leaves(shape: ShapeT, matrix = identity()): Leaf[] {
  if (shape instanceof TransformedShape)
    return leaves(shape.shape, matrix.mul(shape.matrix));
  if (shape.occlusionShape) return leaves(shape.occlusionShape, matrix);
  if (shape instanceof BooleanShape)
    return [...leaves(shape.a, matrix), ...leaves(shape.b, matrix)];
  return [{ shape, matrix, solid: new Solid(shape, matrix) }];
}
function planes(leaf: Leaf): Plane[] {
  const { shape, matrix } = leaf,
    im = matrix.inverse(),
    result: Plane[] = [];
  const add = (n: Vector, p: Vector) =>
    result.push({
      leaf,
      p: matrix.mulPosition(p),
      n: new Vector(
        im.x00 * n.x + im.x10 * n.y + im.x20 * n.z,
        im.x01 * n.x + im.x11 * n.y + im.x21 * n.z,
        im.x02 * n.x + im.x12 * n.y + im.x22 * n.z,
      ).normalize(),
    });
  if (shape instanceof Cube)
    for (const p of [shape.min, shape.max]) for (const n of axis) add(n, p);
  if (shape instanceof Cylinder)
    for (const z of [shape.z0, shape.z1]) add(axis[2], new Vector(0, 0, z));
  if (shape instanceof Cone) add(axis[2], zero);
  return result;
}
/** A sphere expressed in another primitive's local coordinates, if still spherical. */
function localSphere(
  leaf: Leaf,
  frame: Matrix,
): { center: Vector; radius: number } | undefined {
  if (!(leaf.shape instanceof Sphere)) return;
  const m = frame.inverse().mul(leaf.matrix),
    columns = axis.map((a) => direction(m, a));
  const scale = columns[0].length(),
    error = 256 * Number.EPSILON * scale * scale;
  if (
    !(scale > 0) ||
    columns.some((c) => Math.abs(c.lengthSquared() - scale * scale) > error) ||
    Math.abs(columns[0].dot(columns[1])) > error ||
    Math.abs(columns[0].dot(columns[2])) > error ||
    Math.abs(columns[1].dot(columns[2])) > error
  )
    return;
  return {
    center: m.mulPosition(leaf.shape.center),
    radius: leaf.shape.radius * scale,
  };
}

/** First analytic contour families; no tessellated approximation of unsupported surface pairs. */
export function intersectionContours(
  shape: BooleanShape,
  options: ContourOptions,
): Paths {
  if (options.contours === false) return [];
  const extent = shape.boundingBox().max.sub(shape.boundingBox().min).length();
  if (extent === 0 && options.contourTolerance === undefined) return [];
  const tolerance = options.contourTolerance ?? extent * 1e-4;
  const limit = options.maxContourPoints ?? 100000;
  if (
    !(tolerance > 0 && Number.isFinite(tolerance)) ||
    !(limit >= 2 && Number.isSafeInteger(limit))
  )
    throw new Error(
      "Contour tolerance must be positive and finite; maxContourPoints must be an integer >= 2",
    );
  const all = leaves(shape),
    solid = new Solid(shape),
    out: Paths = [];
  if ((all.length * (all.length - 1)) / 2 > 10000)
    throw new Error("Boolean contour pair budget exceeded");
  let points = 0;
  const emit = (path: Vector[], source: Leaf, peer: Leaf, counted = false) => {
    if (path.length < 2) return;
    if (!counted) points += path.length;
    if (points > limit)
      throw new Error(
        "Boolean contour vertex budget exceeded; increase contourTolerance or maxContourPoints",
      );
    out.push(path);
    pathSources.set(path, {
      shape: source.shape,
      matrix: source.matrix,
      intersection: true,
      intersectionSources: [{ shape: peer.shape, matrix: peer.matrix }],
    });
  };
  const boundary = (p: Vector, t: Vector, a: Leaf, b: Leaf) =>
    a.solid.boundary(p, t) && b.solid.boundary(p, t) && solid.boundary(p, t);
  const circle = (c: Vector, u: Vector, v: Vector, a: Leaf, b: Leaf) => {
    // The operator norm is bounded by ||u||+||v||. This bounds world-space
    // sagitta after arbitrary affine transforms, including shear.
    const radiusBound = u.length() + v.length();
    if (!(radiusBound > 0)) return;
    const angleStep = Math.min(
      Math.PI / 4,
      2 * Math.acos(Math.max(-1, 1 - tolerance / radiusBound)),
    );
    if (!(angleStep > 0))
      throw new Error("Contour tolerance is below floating-point resolution");
    const at = (angle: number) =>
      c
        .add(u.multiplyScalar(Math.cos(angle)))
        .add(v.multiplyScalar(Math.sin(angle)));
    const tangent = (angle: number) =>
      v.multiplyScalar(Math.cos(angle)).sub(u.multiplyScalar(Math.sin(angle)));
    const cuts = solid.circleCuts(c, u, v),
      paths: Paths = [];
    let run: Vector[] = [];
    const flush = () => {
      if (run.length > 1) paths.push(run);
      run = [];
    };
    for (let i = 1; i < cuts.length; i++) {
      const lo = cuts[i - 1],
        hi = cuts[i],
        mid = (lo + hi) / 2;
      if (!boundary(at(mid), tangent(mid), a, b)) {
        flush();
        continue;
      }
      const steps = Math.max(1, Math.ceil((hi - lo) / angleStep));
      points += steps + (run.length ? 0 : 1);
      if (points > limit)
        throw new Error(
          "Boolean contour vertex budget exceeded; increase contourTolerance or maxContourPoints",
        );
      if (!run.length) run.push(at(lo));
      for (let j = 1; j <= steps; j++)
        run.push(at(j === steps ? hi : lo + ((hi - lo) * j) / steps));
    }
    flush();
    // Close periodic contours with exactly the same endpoint and join wrapping arcs.
    const first = paths[0],
      last = paths[paths.length - 1],
      seam = at(0);
    const error =
      128 * Number.EPSILON * Math.max(c.length(), radiusBound, 1e-100);
    if (
      first &&
      first[0].distance(seam) <= error &&
      last[last.length - 1].distance(seam) <= error
    ) {
      last[last.length - 1] = first[0];
      if (first !== last) {
        paths[0] = last.concat(first.slice(1));
        paths.pop();
      }
    }
    for (const path of paths) {
      emit(path, a, b, true);
      if (path[0] === path[path.length - 1]) {
        const im = a.matrix.inverse(),
          source = pathSources.get(path)!;
        source.closedCurve = {
          center: im.mulPosition(c),
          u: direction(im, u),
          v: direction(im, v),
        };
      }
    }
  };
  const localCircle = (
    leaf: Leaf,
    center: Vector,
    normal: Vector,
    radius: number,
    other: Leaf,
  ) => {
    if (!(radius > 0)) return;
    const u = normal
        .cross(Math.abs(normal.x) < 0.8 ? axis[0] : axis[1])
        .normalize()
        .multiplyScalar(radius),
      v = normal.cross(u);
    circle(
      leaf.matrix.mulPosition(center),
      direction(leaf.matrix, u),
      direction(leaf.matrix, v),
      leaf,
      other,
    );
  };
  const spherePlane = (sphere: Leaf, plane: Plane) => {
    if (!(sphere.shape instanceof Sphere)) return;
    const m = sphere.matrix,
      normal = new Vector(
        direction(m, axis[0]).dot(plane.n),
        direction(m, axis[1]).dot(plane.n),
        direction(m, axis[2]).dot(plane.n),
      );
    const length = normal.length(),
      n = normal.divScalar(length),
      p = m.inverse().mulPosition(plane.p),
      center = sphere.shape.center;
    const distance = center.sub(p).dot(n),
      r = sphere.shape.radius;
    if (!(Math.abs(distance) < r)) return;
    localCircle(
      sphere,
      center.sub(n.multiplyScalar(distance)),
      n,
      Math.sqrt((r - distance) * (r + distance)),
      plane.leaf,
    );
  };
  const sphereRound = (sphere: Leaf, round: Leaf) => {
    const r = round.shape;
    if (!(r instanceof Cylinder || r instanceof Cone)) return;
    const s = localSphere(sphere, round.matrix);
    if (!s) return;
    const epsilon =
      128 *
      Number.EPSILON *
      Math.max(s.radius, Math.abs(s.center.z), r.radius, 1e-100);
    if (Math.hypot(s.center.x, s.center.y) > epsilon) return;
    const z0 = r instanceof Cylinder ? r.z0 : 0,
      z1 = r instanceof Cylinder ? r.z1 : r.height;
    const k = r instanceof Cone ? r.radius / r.height : 0,
      base = r instanceof Cone ? r.radius : 0;
    if (
      r instanceof Cylinder &&
      Math.abs(s.radius * s.radius - r.radius * r.radius) <=
        128 *
          Number.EPSILON *
          Math.max(s.radius * s.radius, r.radius * r.radius)
    )
      return;
    if (r instanceof Cone) {
      const aa = 1 + k * k,
        bb = -2 * (s.center.z + k * base),
        cc = s.center.z * s.center.z + base * base - s.radius * s.radius;
      if (
        Math.abs(bb * bb - 4 * aa * cc) <=
        128 * Number.EPSILON * (bb * bb + Math.abs(4 * aa * cc))
      )
        return;
    }
    const zs =
      r instanceof Cylinder
        ? quadratic(
            1,
            -2 * s.center.z,
            s.center.z * s.center.z + r.radius * r.radius - s.radius * s.radius,
          )
        : quadratic(
            1 + k * k,
            -2 * (s.center.z + k * base),
            s.center.z * s.center.z + base * base - s.radius * s.radius,
          );
    for (const z of unique(zs))
      if (z > z0 && z < z1) {
        const radius =
          r instanceof Cylinder ? r.radius : r.radius * (1 - z / r.height);
        // Prefer sphere provenance for sphere/cone/cylinder seams.
        const c = round.matrix.mulPosition(new Vector(0, 0, z));
        circle(
          c,
          direction(round.matrix, new Vector(radius, 0, 0)),
          direction(round.matrix, new Vector(0, radius, 0)),
          sphere,
          round,
        );
      }
  };
  const planePair = (a: Plane, b: Plane) => {
    const cross = a.n.cross(b.n),
      length = cross.length();
    if (length <= 64 * Number.EPSILON) return;
    const d = cross.divScalar(length),
      point = b.n
        .cross(cross)
        .multiplyScalar(a.n.dot(a.p))
        .add(cross.cross(a.n).multiplyScalar(b.n.dot(b.p)))
        .divScalar(length * length);
    const boxA = a.leaf.matrix.mulBox(a.leaf.shape.boundingBox()),
      boxB = b.leaf.matrix.mulBox(b.leaf.shape.boundingBox());
    const min = boxA.min.max(boxB.min),
      max = boxA.max.min(boxB.max);
    if (min.x > max.x || min.y > max.y || min.z > max.z) return;
    const parameters: number[] = [];
    for (const x of [min.x, max.x])
      for (const y of [min.y, max.y])
        for (const z of [min.z, max.z])
          parameters.push(new Vector(x, y, z).sub(point).dot(d));
    const start = point.add(d.multiplyScalar(Math.min(...parameters))),
      end = point.add(d.multiplyScalar(Math.max(...parameters))),
      delta = end.sub(start);
    if (!delta.length()) return;
    const cuts = solid.cuts(start, end);
    for (let i = 1; i < cuts.length; i++) {
      const lo = cuts[i - 1],
        hi = cuts[i],
        mid = start.add(delta.multiplyScalar((lo + hi) / 2));
      if (boundary(mid, d, a.leaf, b.leaf))
        emit(
          [
            start.add(delta.multiplyScalar(lo)),
            start.add(delta.multiplyScalar(hi)),
          ],
          a.leaf,
          b.leaf,
        );
    }
  };
  for (let i = 0; i < all.length; i++)
    for (let j = 0; j < i; j++) {
      const a = all[i],
        b = all[j];
      const pa = planes(a),
        pb = planes(b);
      for (const p of pb) spherePlane(a, p);
      for (const p of pa) spherePlane(b, p);
      sphereRound(a, b);
      sphereRound(b, a);
      if (a.shape instanceof Sphere && b.shape instanceof Sphere) {
        const bs = localSphere(b, a.matrix);
        if (bs) {
          const diff = bs.center.sub(a.shape.center),
            dist = diff.length(),
            r = a.shape.radius,
            s = bs.radius;
          if (dist > Math.abs(r - s) && dist < r + s) {
            const n = diff.divScalar(dist),
              h = (dist * dist + (r - s) * (r + s)) / (2 * dist);
            localCircle(
              a,
              a.shape.center.add(n.multiplyScalar(h)),
              n,
              Math.sqrt(Math.max(0, (r - h) * (r + h))),
              b,
            );
          }
        }
      }
      for (const p of pa) for (const q of pb) planePair(p, q);
    }
  return out;
}
