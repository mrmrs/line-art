import type { ShapeT } from "./shape";
import type { Matrix } from "./matrix";
import type Vector from "./vector";
/** Internal provenance survives Boolean trimming and instance transforms. */
export interface PathSource {
  shape: ShapeT;
  matrix: Matrix;
  intersection?: boolean;
  /** Other incident surfaces for a generated seam, in the same world frame. */
  intersectionSources?: PathSource[];
  /** Complete analytic ellipse, expressed in the source shape frame. */
  closedCurve?: { center: Vector; u: Vector; v: Vector };
}
export const pathSources = new WeakMap<Vector[], PathSource>();
