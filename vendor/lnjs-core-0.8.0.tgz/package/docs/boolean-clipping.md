# Boolean clipping introduced in 0.7.0

Version 0.8.0 extends this engine with [analytic intersection contours](boolean-contours.md) for selected primitive pairs. The remaining sections describe the original clipping algorithm.

`Visibility` clips union, intersection and difference solids using surface events. It no longer scans a Boolean silhouette at fixed pixel intervals. `BooleanShape.paths()` also replaces the old 0.01-world-unit chopping with intersections between each operand stroke and the other operand's boundary surfaces.

Supported operands are cubes, spheres, closed cylinders, closed cones, closed consistently wound triangle meshes, nested Booleans, and invertible affine instances of those shapes. `occlusionShape` wrappers delegate to their underlying solid. An open triangle, height field, or arbitrary custom implicit surface is rejected with an actionable error. Empty shapes are allowed.

## Arrangement algorithm

For a clipped world stroke `P(s) = a + s(b-a)`, the viewing rays form a pencil:

- Perspective: `X(s,u) = eye + u(P(s)-eye)`, with source depth `u=1`.
- Orthographic: `X(s,u) = P(s) + u direction`, with source depth `u=0`.

Every leaf boundary is a plane or quadric. Substitution produces `A(s)u² + B(s)u + C(s) = 0`. Local equations retain their centers and instance inverses rather than expanding large world translations. Mesh triangles also contribute edge-domain guard planes.

The clipper partitions `[0,1]` at:

1. Surface tangencies (`B²-4AC=0`) and degree changes.
2. Source and camera near-plane intersections.
3. Pairwise resultants, where two boundary depths coincide and change order.
4. Subresultant events for degenerate ray pencils with a shared root.

Plane/plane, plane/quadric and quadric/quadric resultants have degree at most four in this pencil. Linear/quadratic equations use direct roots. Higher degrees use derivative roots to partition monotone intervals, with bracketed root isolation and stationary-root checks.

Each resulting cell has a fixed ordering of depth boundaries. One representative ray per cell supplies the ordered depth slabs; the Boolean expression classifies their interiors. Any occupied slab between the stroke and near plane hides that entire parameter cell. This representative-cell classification depends on the algebraic event partition, not a sampling density. Perspective output converts world parameter `s` to projected parameter `s wb / ((1-s)wa+s wb)`.

Boundary neighborhood classification removes zero-volume intersections and distinguishes shared internal union interfaces from external surfaces. Mesh containment checks finite face boundaries before parity queries. Mesh validation requires nondegenerate faces and exactly two oppositely directed incidences for every edge.

## Stroke behavior

Operand polylines are split at plane/quadric roots; surviving runs stay separate. Difference retains appropriate cutter strokes. Identical polylines are deduplicated. Coincident operand boundaries receive neighborhood classification rather than a blanket inclusive containment test.

Internal path provenance survives Boolean trimming and affine transforms. For a source-owned curved stroke, visibility adjusts its depth to the incident analytic surface along the same viewing ray. This prevents the small inward sag of a polyline chord from turning visible surface strokes into dots. Incident cap and side surfaces are considered together at cylinder/cone rims. Call `scene.paths()` and `renderPaths()` to preserve that provenance.

## Precision and limits

“Exact Boolean clipping” here means geometric boundary events replace fixed-step searching. Computation still uses IEEE-754 doubles: it is not a certified exact-arithmetic CAD kernel. Roots closer than the numerical uncertainty may merge. Extremely ill-conditioned tangencies, huge translations relative to feature size, and singular/near-singular inputs need further adversarial testing.

Curved drawing paths remain the primitives' existing polylines. Trimming those chords does not construct new surface-intersection curves, such as the circular seam where a cylinder cuts a sphere. That contour-generation problem is a separate next step. Exact duplicate curved-surface descriptions are recognized for coincident stroke handling; arbitrary algebraically equivalent parameterizations are not canonicalized.

Boolean event construction is quadratic in the number of boundary/guard surfaces per stroke. `VisibilityOptions.maxTests` bounds event and classification work and throws on exhaustion. Dense meshes may require smaller inputs or a higher budget; spatial pruning of surface pairs is future work. No silent sampled fallback is used for unsupported or over-budget Booleans. Open, nonmanifold and inconsistently wound meshes are rejected; self-intersections and inconsistent nesting of disconnected shells are not repaired or exhaustively validated.

Custom shapes outside Booleans retain the existing fallback. Standalone cylinder/cone visibility still uses tolerance-driven tessellation. The separate `intersect`/`occluded` ray API retains its previous bounded traversal and is not a new topology-building Boolean API.

## Validation and reproduction

`npm test` covers thin slits/blockers, near-tangent sphere lenses, coincident/touching operands, internal union seams, nested affine transforms, perspective and orthographic cameras, near-plane events, closed meshes, source-curve continuity, and scale sweeps from 1e-6 to 1e6. A seeded comparison checks 10,800 classifications against independently enumerated primitive ray intersections and Boolean depth slabs, plus 500 near-plane comparisons.

Run `npm run bench:boolean` for current-engine figures. To compare with the previously packed 0.6.0 engine:

```sh
LN_BASELINE=/path/to/extracted/0.6.0/package node benchmarks/boolean.cjs comparison.svg
```

The gallery magnifies already-rendered output, preserving the old camera and sample spacing. It does not rerender the sampled engine with a zoomed camera that would conceal the original failure.
