# Analytic intersection contours in 0.8.0

Boolean shapes now generate supported surface-intersection curves in addition to trimming their operands' existing strokes. This closes the outlines of planar cuts, sphere lenses, and coaxial bores that 0.7.0 could clip but could not draw completely.

## Supported families

- Plane/plane seams between box faces, cylinder caps, and cone bases.
- Sphere/plane circles, including affine ellipsoids cut by those planar faces.
- Sphere/sphere circles where the relative instance transform preserves spheres. This includes ordinary spheres and pairs sharing a common nonuniform affine transform.
- Coaxial sphere/cylinder and sphere/cone circles, also under a common affine transform. The sphere center must lie on the round primitive's axis in its local frame, and remain spherical there.

Other surface pairs retain their existing clipped operand strokes. This release does not generate arbitrary ellipsoid/ellipsoid, off-axis sphere/cylinder, general cylinder/cone, or mesh intersection curves. It does not approximate unsupported pairs with a hidden marching grid.

## Controls

The optional fourth `BooleanShape` constructor argument is a `ContourOptions` object:

```ts
const cut = new ln.BooleanShape(ln.CSGOperation.Difference, sphere, cutter, {
  contours: true,             // default
  contourTolerance: 0.0001,   // world units in this Boolean's coordinate frame
  maxContourPoints: 100000,   // default generated-vertex budget
});
```

If omitted, tolerance is `1e-4` times the Boolean bounding-box diagonal. An outer instance transforms that tolerance with its geometry; it is not a fixed pixel or physical pen-width guarantee. `contours: false` restores clipped-operand-only drawing. It does not alter occlusion.

For a generated affine circle `C + U cos(theta) + V sin(theta)`, the subdivision uses a conservative sagitta bound based on `|U|+|V|`. Arc endpoints are analytic surface events, not positions recovered from chopping the output polyline. Work is bounded by 10,000 candidate leaf pairs and the generated-vertex limit; exhaustion throws explicitly.

## Nested cuts and visibility

All relevant leaf pairs are considered against the complete Boolean expression. Child-generated contours are rebuilt at the parent level, so subsequent cuts intersect the analytic curve instead of its previously tessellated chords. Two bounded tangent-half-angle charts reduce plane/quadric events along a circle to polynomials of degree at most four. Finite-face and regularized-solid boundary tests select surviving arcs. Periodic arcs are joined across their parameter seam, and closed curves repeat exactly the same endpoint.

Generated paths retain both incident surface records through instance transforms. Visibility adjusts the depth of approximating chords using those surfaces, which keeps an exposed planar rim complete in an oblique view. In orthographic views, complete parallel ellipses that coincide in projection are plotted once at the nearest depth. A contour crossing the near/far plane does not suppress a farther visible contour.

Tangent contacts and zero-radius circles are omitted. Boundary classification accounts for affine transform roundoff, and radial membership distinguishes a numerical boundary from a tiny false exterior gap. This remains IEEE-754 floating-point geometry, not a certified CAD topology kernel.

## Validation

Fifteen new regression cases cover circle closure and surface equations, thin sphere lenses, coaxial bores and cones, finite plane seams, affine transforms, tolerance bounds, vertex-budget errors, nested endpoint alignment, full oblique rims, projected coincident rims, and near-plane clipping. They run alongside all 40 tests from 0.7.0.

Generate a before/after gallery against the packed 0.7.0 baseline:

```sh
LN_BASELINE=/path/to/extracted/0.7.0/package node benchmarks/contours.cjs gallery.svg
```

The gallery draws generated seams in blue. Its timing output is one diagnostic run, not a performance benchmark. This feature adds geometry and boundary-classification work; general Boolean event-pair acceleration remains a separate follow-up.
