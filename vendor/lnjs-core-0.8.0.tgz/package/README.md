# ln.js — continuous hidden-line rendering

A maintained fork of [aweary/ln.js](https://github.com/aweary/ln.js), originally a JavaScript port of [fogleman/ln](https://github.com/fogleman/ln). Generates vector linework for SVG and pen plotting.

Version 0.8.0 adds analytic intersection contours for planar seams, sphere cuts/lenses, and coaxial sphere bores/cone cuts. [Supported pairs, precision controls, and limits](docs/boolean-contours.md).

Version 0.7.0 added event-based Boolean clipping for nested analytic solids and closed meshes, including operand-stroke trimming without fixed-distance chopping. See [the Boolean algorithm and limits](docs/boolean-clipping.md).

Version 0.6.0 replaced sampled hidden-line removal with continuous segment clipping for triangle meshes and boxes, and analytic visibility intervals for spheres and transformed ellipsoids. It fixes transformed ray distances, parallel boundary rays, closed primitive caps, Boolean traversal, and small-triangle intersections.

```ts
import * as ln from '@lnjs/core';

const scene = new ln.Scene();
scene.add(new ln.Cube(new ln.Vector(-1, -1, -1), new ln.Vector(1, 1, 1)));
const eye = new ln.Vector(6, 5, 7);
const matrix = ln.lookAt(eye, new ln.Vector(0, 0, 0), new ln.Vector(0, 0, 1))
  .perspective(45, 1, 0.1, 100);
const paths = scene.renderWithMatrix(matrix, eye, 1000, 1000, 0.1, {
  curveTolerance: 0.1,
});
const svg = ln.toSVG(paths, 1000, 1000);
```

The `step` argument remains for source compatibility. Continuous geometry visibility does not depend on it. `curveTolerance` is a projected-pixel tessellation target for cylinders/cones and controls fallback boundary refinement; it is not a global mathematical error guarantee.

For orthographic output, use an orthographic matrix; the renderer derives parallel visibility rays automatically. Surface queries stop at the near plane. Geometry between the near plane and the eye does not hide exported paths.

For custom paths and explicit acceleration reuse:

```ts
scene.compile();
const visibility = new ln.Visibility(scene, matrix, eye, 1000, 1000, {
  curveTolerance: 0.1,
  fallbackSpacing: 0.5,
  maxTriangles: 1_000_000,
  maxTests: 20_000_000,
});
const output = ln.renderPaths(worldPaths, matrix, 1000, 1000, visibility);
console.log(visibility.stats);
```

Call `scene.paths()` when rendering scene-owned paths. It records ownership so sphere surface polylines do not incorrectly occlude their own approximating chords. `Visibility.visible(a, b, owner?)` returns intervals in **projected segment parameterization**, not world-space parameterization. Clip world endpoints with `clipSegment` first. `renderPaths` handles both details.

Custom shapes may expose `occlusionTriangles()` or delegate through `occlusionShape`. Return an empty triangle array for marks that never occlude. Custom triangle arrays must represent the same coordinate system as the shape. Camera-specific visibility indexes are immutable snapshots: rebuild after geometry or camera changes.

`scene.occluded(ray, tMin, tMax, filter?)` provides bounded any-hit queries; `scene.intersect` retains nearest-hit queries. `Tree.stats` counts visits and primitive tests. Ray parameters remain consistent through nested and nonuniform transforms. `NoHit.t` is now `Infinity`; prefer `hit.ok()` to inspecting its value.

Mesh paths deduplicate shared edges by default. `mesh.paths({mode: 'creases', creaseAngle: 30})` removes coplanar interior edges. `mode: 'silhouette'` accepts an `eye` or orthographic `direction`. Mesh containment and Boolean solids require closed meshes; arbitrary open imports have no reliable inside/outside interpretation.

Height fields use a shared bounded Cartesian mesh for paths and ray tests. `new ln.Function(fn, box, direction, divisions = 64)` accepts 4–512 grid divisions. This replaces the old hard-coded radial paths and distance-limited marcher. High-frequency or discontinuous functions still require appropriate resolution; this is a tessellated surface, not a guaranteed analytic root solver.

Cylinders and cones are closed solids. Standalone curved surfaces use tessellation for vector visibility; within Booleans they use analytic surface events. Supported Booleans do not use `fallbackSpacing` or `curveTolerance`. Arbitrary custom shapes outside Booleans may still use projected sampling with refined transitions. Unsupported Boolean operands fail explicitly instead of silently sampling. The separate Boolean ray-query API retains bounded iterative boundary traversal.

Boolean clipping uses double-precision polynomial roots, not certified exact arithmetic. Curved drawing paths remain polylines. Supported intersection contours are generated analytically and tessellated to a configurable world-space tolerance; unsupported surface pairs still contribute only their existing clipped strokes. Large Boolean meshes require substantial work; `maxTests` limits event and classification work and reports exhaustion explicitly. Closed-mesh validation checks edge incidence and winding, but does not repair or detect every self-intersection.

Development:

```sh
npm ci
npm test
npm run bench
npm pack
```

The package has no runtime dependencies. CommonJS, bundler ESM, and declarations are built from TypeScript. The sibling line-art app vendors the packed artifact and its integrity in its lockfile; `node scripts/update-ln-fork.mjs` in that app runs the fork tests and refreshes it. The artifact allows an app checkout to install without a sibling checkout or an unpublished registry release.

To compare against an unmodified installed upstream package:

```sh
LN_BASELINE=/path/to/upstream/package npm run bench
LN_BASELINE=/path/to/upstream/package node benchmarks/gallery.cjs comparison.svg
```

Tests cover analytic references, 2,000 seeded BVH/brute-force comparisons, scale sweeps, shared triangle boundaries, transformed ellipsoids, thin occluders, CSG, near-plane clipping, and path continuity. Benchmarks report construction separately from queries and end-to-end rendering; performance varies with scene structure. The robustness approach draws on [watertight shear-space triangle tests](https://jcgt.org/published/0002/01/05/) and [bounded ray-intersection interfaces](https://pbr-book.org/4ed/Primitives_and_Intersection_Acceleration/Primitive_Interface_and_Geometric_Primitives).
