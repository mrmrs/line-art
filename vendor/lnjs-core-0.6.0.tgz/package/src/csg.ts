import { ShapeT, EmptyShape } from "./shape";
import { FilterT } from "./filter";
import Vector from "./vector";
import Ray from "./ray";
import Hit, { NoHit } from "./hit";
import { after, rayEpsilon } from "./numeric";
import * as Paths from "./paths";

export enum CSGOperation {
  Intersection,
  Difference,
  Union,
}

export class BooleanShape implements ShapeT, FilterT {
  op: CSGOperation;
  a: ShapeT;
  b: ShapeT;

  static create(op: CSGOperation, ...shapes: ShapeT[]): ShapeT {
    if (shapes.length === 0) {
      return new EmptyShape();
    }
    let shape = shapes[0];
    for (let i = 1; i < shapes.length; i++) {
      shape = new BooleanShape(op, shape, shapes[i]);
    }
    return shape;
  }

  constructor(op: CSGOperation, a: ShapeT, b: ShapeT) {
    this.op = op;
    this.a = a;
    this.b = b;
  }

  compile() {
    this.a.compile();
    this.b.compile();
  }

  boundingBox() {
    let a = this.a.boundingBox();
    let b = this.b.boundingBox();
    return a.extend(b);
  }

  contains(v: Vector, f: number): boolean {
    switch (this.op) {
      case CSGOperation.Union:
        return this.a.contains(v, f) || this.b.contains(v, f);
      case CSGOperation.Intersection:
        return this.a.contains(v, f) && this.b.contains(v, f);
      case CSGOperation.Difference:
        return this.a.contains(v, f) && !this.b.contains(v, -f);
    }
    return false;
  }

  intersect(r: Ray, tMin = rayEpsilon(r), tMax = Infinity): Hit {
    // Keep one ray parameterization throughout; never step the origin by a fixed gap.
    let cursor = tMin;
    let inside = this.contains(r.position(after(cursor)), 0);
    for (let i = 0; i < 100000; i++) {
      const h = this.a
        .intersect(r, cursor, tMax)
        .min(this.b.intersect(r, cursor, tMax));
      if (!h.ok() || h.t >= tMax) return NoHit;
      const next = after(h.t);
      const state = this.contains(r.position(next), 0);
      if (state !== inside) return new Hit(this, h.t);
      inside = state;
      cursor = next;
    }
    throw new Error("Boolean boundary budget exceeded");
  }

  paths() {
    let a = this.a.paths();
    let b = this.b.paths();
    let p = a.concat(b);
    return Paths.filterPaths(Paths.chop(p, 0.01), this);
  }

  filter(v: Vector): [Vector, boolean] {
    return [v, this.contains(v, 0)];
  }
}
